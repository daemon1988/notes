package com.das.common.result;

/**
 * 枚举类
 * @author : zhangxi
 * @date : 2018-02-24 22:05
 */
public enum UpmsEnum {
	
    /**
     * 成功
     */
    SUCCESS(1,"success"),
    /**
     * 失败
     */
    FAILED(-1,"failed"),
    /**
     * 长度错误
     */
    INVALID_LENGTH(10001, "Invalid length"),
    /**
     * 用户名不能为空
     */
    EMPTY_USERNAME(10101, "Username cannot be empty"),
    /**
     * 密码不能为空
     */
    EMPTY_PASSWORD(10102, "Password cannot be empty"),
    /**
     * 账号不存在
     */
    INVALID_USERNAME(10103, "Account does not exist"),
    /**
     * 密码错误
     */
    INVALID_PASSWORD(10104, "Password error"),
    /**
     * 账号不可用
     */
    INVALID_ACCOUNT(10105, "Invalid account");
    /**
     * 定义错误编码
     */
    public int codeMessage;
    /**
     * 定义错误信息
     */
    public String message;

    UpmsEnum(int codeMessage, String message) {
        this.codeMessage = codeMessage;
        this.message = message;
    }

    public int getCodeMessage() {
        return codeMessage;
    }

    public void setCodeMessage(int codeMessage) {
        this.codeMessage = codeMessage;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}
