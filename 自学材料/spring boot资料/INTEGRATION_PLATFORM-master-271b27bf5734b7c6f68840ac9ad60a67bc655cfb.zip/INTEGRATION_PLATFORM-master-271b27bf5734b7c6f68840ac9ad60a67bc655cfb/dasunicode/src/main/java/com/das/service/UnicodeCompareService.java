package com.das.service;

import com.das.domain.UnicodeCompare;

import java.util.List;

public interface UnicodeCompareService {
	
    /**
     * 根据表名查询数据
     * @param tableName
     * @return UnicodeCompare
     */
    UnicodeCompare getUnicodeCompareByTableName(String tableName);

    /**
     * 查询所有数据
     * @return
     */
    List<UnicodeCompare> listAllUniCodeCompare();

    /**
     * 插入数据
     * @param unicodeCompare
     * @return
     */
    int insertSelective(UnicodeCompare unicodeCompare);

    /**
     * 删除数据
     * @param tableName
     */
    public void deleteByTableName(String tableName);

    /**
     * 按条件查询数据
     * @param unicodeCompare
     * @return
     */
   public List<UnicodeCompare> listUnicodeCompareByCondition(UnicodeCompare unicodeCompare);

    /**
     * 更新
     * @param unicodeCompare
     */
    public void updateUnicodeCompare(UnicodeCompare unicodeCompare);

}
