package com.das.common.util;

import java.util.UUID;

/**
 * uuid工具
 * @author zhangxi
 */
public class UuidUtils {	
    /**
     * 获取32位uid
     */
    public static String get32Uid() {
        String uuid = UUID.randomUUID().toString().trim().replaceAll("-", "");
        return uuid;
    }
}
