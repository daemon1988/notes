package com.das.service;

import com.das.domain.User;
import com.das.domain.UserTemp;

import java.util.List;

public interface UserTempService {
    /**
     * 查询新增状态的用户
     * @return
     */
    List<UserTemp> listAllUserTempWithNewStatus();

    /**
     * 批量更改用户状态
     * @param list
     */
    void changeStatus(List list);

    /**
     * 插入用户
     */
    void insertUser(User user);
}
