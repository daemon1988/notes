package com.das.domain;

import java.io.Serializable;

/**
 * 定时任务类
 * @author : zhangxi
 * @date : 2018-02-24 21:43
 */
public class ScheduleJob implements Serializable{
	
    /**
     * id,主键
     */
    private Integer id;
    /**
     * 任务名称
     */
    private String jobName;
    /**
     * 任务分组
     */
    private String jobGroup;
    /**
     * 定时任务状态，0表示正常，1表示暂停
     */
    private Integer status;
    /**
     * 时间表达式
     */
    private String cronExpression;
    /**
     * spring bean名称,任务执行是调用那个类的方法
     */
    private String beanClass;
    /**
     * params参数
     */
    private String params;
    /**
     * SpringId
     */
    private String springId;
    /**
     * 方法名称
     */
    private String methodName;

    /**
     * 备注
     */
    private String remark;

    /**
     * 创建时间
     */
    private String createTime;

    /**
     * 修改时间
     */
    private String modifyTime;

    public ScheduleJob(Integer id, String jobName, String jobGroup, Integer status, String cronExpression, String beanClass, String springId, String methodName, String remark, String createTime, String modifyTime) {
        this.id = id;
        this.jobName = jobName;
        this.jobGroup = jobGroup;
        this.status = status;
        this.cronExpression = cronExpression;
        this.beanClass = beanClass;
        this.springId = springId;
        this.methodName = methodName;
        this.remark = remark;
        this.createTime = createTime;
        this.modifyTime = modifyTime;
    }

    public ScheduleJob() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getJobName() {
        return jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

    public String getJobGroup() {
        return jobGroup;
    }

    public void setJobGroup(String jobGroup) {
        this.jobGroup = jobGroup;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getCronExpression() {
        return cronExpression;
    }

    public void setCronExpression(String cronExpression) {
        this.cronExpression = cronExpression;
    }

    public String getBeanClass() {
        return beanClass;
    }

    public void setBeanClass(String beanClass) {
        this.beanClass = beanClass;
    }

    public String getSpringId() {
        return springId;
    }

    public void setSpringId(String springId) {
        this.springId = springId;
    }

    public String getMethodName() {
        return methodName;
    }

    public void setMethodName(String methodName) {
        this.methodName = methodName;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(String modifyTime) {
        this.modifyTime = modifyTime;
    }

    public String getParams() {
        return params;
    }

    public void setParams(String params) {
        this.params = params;
    }

    @Override
    public String toString() {
        return "ScheduleJob{" +
                "id=" + id +
                ", jobName='" + jobName + '\'' +
                ", jobGroup='" + jobGroup + '\'' +
                ", status=" + status +
                ", cronExpression='" + cronExpression + '\'' +
                ", beanClass='" + beanClass + '\'' +
                ", params='" + params + '\'' +
                ", springId='" + springId + '\'' +
                ", methodName='" + methodName + '\'' +
                ", remark='" + remark + '\'' +
                ", createTime='" + createTime + '\'' +
                ", modifyTime='" + modifyTime + '\'' +
                '}';
    }
}
