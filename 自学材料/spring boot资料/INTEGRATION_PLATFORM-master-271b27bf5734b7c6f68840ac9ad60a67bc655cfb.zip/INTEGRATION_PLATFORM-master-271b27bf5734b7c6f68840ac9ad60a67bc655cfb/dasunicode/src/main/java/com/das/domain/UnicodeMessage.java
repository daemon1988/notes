package com.das.domain;

public class UnicodeMessage {
    private String registerMessageName;
    private String messageId;

    public UnicodeMessage() {
    }

    public UnicodeMessage(String registerMessageName, String messageId) {
        this.registerMessageName = registerMessageName;
        this.messageId = messageId;
    }

    public String getRegisterMessageName() {
        return registerMessageName;
    }

    public void setRegisterMessageName(String registerMessageName) {
        this.registerMessageName = registerMessageName;
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    @Override
    public String toString() {
        return "UnicodeMessage{" +
                "registerMessageName='" + registerMessageName + '\'' +
                ", messageId='" + messageId + '\'' +
                '}';
    }
}
