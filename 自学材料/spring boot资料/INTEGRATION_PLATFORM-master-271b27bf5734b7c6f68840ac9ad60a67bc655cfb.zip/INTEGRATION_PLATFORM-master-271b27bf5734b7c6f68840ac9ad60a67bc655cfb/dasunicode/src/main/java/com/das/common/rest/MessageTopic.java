package com.das.common.rest;

/**
 * @author 赵磊
 * @version 1.0
 * 日期: 2018/3/27
 */
public class MessageTopic {
    private String messageId;
    private String type;
    private String content;

    public MessageTopic() {
    }

    public MessageTopic(String messageId, String type, String content) {
        this.messageId = messageId;
        this.type = type;
        this.content = content;
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
    
}
