package com.das.domain;

public class Json {
	
    private String messageId;
    private String content;
    private String type;

    public Json() {
    }

    public Json(String messageId, String content, String type) {
        this.messageId = messageId;
        this.content = content;
        this.type = type;
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "Json{" +
                "messageId='" + messageId + '\'' +
                ", content='" + content + '\'' +
                ", type='" + type + '\'' +
                '}';
    }
}
