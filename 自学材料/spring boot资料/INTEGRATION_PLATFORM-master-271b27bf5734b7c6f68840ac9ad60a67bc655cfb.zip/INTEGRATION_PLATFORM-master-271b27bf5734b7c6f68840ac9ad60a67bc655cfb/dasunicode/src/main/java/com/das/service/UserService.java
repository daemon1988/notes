package com.das.service;

import com.das.domain.User;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * 用户业务层
 *
 * @author : zhangxi
 * @date : 2018-02-24 22:24
 */
public interface UserService {
    /**
     * 根据用户名获取用户详细信息
     * @param username
     * @return User
     */
    User getUserByUsername(String username);

    /**
     * 根据用户名和密码登录
     * @param username
     * @param password
     * @param response
     * @return
     */
    String loginByUserNameAndPassword(String username, String password, HttpServletResponse response);

    /**
     *添加新用户
     */
    void insertUser(User user);

    /**
     * 查询所有的用户列表
     * @return
     */
    List<User> listAllUser();

    /**
     * 更新用户信息
     * @param user
     */
    void updateUser(User user);

    /**
     * 按条件查询用户列表
     * @param user
     * @return List<User>
     */
    List<User> listUserByCondition(User user);

    /**
     * 批量删除用户
     * @param list
     */
    void delUserById(List list);

    /**
     * 删除单个用户
     */
    void delUser(User user);
}
