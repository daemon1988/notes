package com.das.domain;

import java.util.Date;

public class SysIoShareTable {
	
    private String tableName;

    private String tableDesc;

    private String read;

    private String write;

    private String listen;

    private String optUser;

    private Date optDate;

    private String optTerm;

    private String chnDesc;

    private String engDesc;

    private String py1;

    private String py2;

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName == null ? null : tableName.trim();
    }

    public String getTableDesc() {
        return tableDesc;
    }

    public void setTableDesc(String tableDesc) {
        this.tableDesc = tableDesc == null ? null : tableDesc.trim();
    }

    public String getRead() {
        return read;
    }

    public void setRead(String read) {
        this.read = read == null ? null : read.trim();
    }

    public String getWrite() {
        return write;
    }

    public void setWrite(String write) {
        this.write = write == null ? null : write.trim();
    }

    public String getListen() {
        return listen;
    }

    public void setListen(String listen) {
        this.listen = listen == null ? null : listen.trim();
    }

    public String getOptUser() {
        return optUser;
    }

    public void setOptUser(String optUser) {
        this.optUser = optUser == null ? null : optUser.trim();
    }

    public Date getOptDate() {
        return optDate;
    }

    public void setOptDate(Date optDate) {
        this.optDate = optDate;
    }

    public String getOptTerm() {
        return optTerm;
    }

    public void setOptTerm(String optTerm) {
        this.optTerm = optTerm == null ? null : optTerm.trim();
    }

    public String getChnDesc() {
        return chnDesc;
    }

    public void setChnDesc(String chnDesc) {
        this.chnDesc = chnDesc == null ? null : chnDesc.trim();
    }

    public String getEngDesc() {
        return engDesc;
    }

    public void setEngDesc(String engDesc) {
        this.engDesc = engDesc == null ? null : engDesc.trim();
    }

    public String getPy1() {
        return py1;
    }

    public void setPy1(String py1) {
        this.py1 = py1 == null ? null : py1.trim();
    }

    public String getPy2() {
        return py2;
    }

    public void setPy2(String py2) {
        this.py2 = py2 == null ? null : py2.trim();
    }
}