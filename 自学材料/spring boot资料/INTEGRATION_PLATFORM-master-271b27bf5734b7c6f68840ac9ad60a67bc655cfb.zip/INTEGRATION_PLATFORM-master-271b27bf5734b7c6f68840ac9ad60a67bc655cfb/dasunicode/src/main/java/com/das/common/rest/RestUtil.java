package com.das.common.rest;

import com.alibaba.fastjson.JSONObject;
import com.das.common.configuration.AddressConfiguration;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.ObjectMapper;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.Base64;

/**
 * @author 赵磊
 * @version 1.0
 * 日期: 2018/3/27
 */
public class RestUtil {
    private static final com.fasterxml.jackson.databind.ObjectMapper MAPPER = new com.fasterxml.jackson.databind.ObjectMapper();

    public static void init(){
        Unirest.setObjectMapper(new ObjectMapper() {

            @Override
            public <T> T readValue(String s, Class<T> aClass) {
                try {
                    return MAPPER.readValue(s, aClass);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }

            @Override
            public String writeValue(Object o) {
                try {
                    return MAPPER.writeValueAsString(o);
                } catch (JsonProcessingException e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }

    public static HttpResponse getToken() throws UnirestException, JsonProcessingException{
        init();
        HttpResponse<Oauth2Token> token = Unirest.post(AddressConfiguration.HIPADDRESS + "/oauth/token")
                .header("Content-Type", "application/x-www-form-urlencoded")
                .header("Authorization", "Basic " + new String(Base64.getEncoder().encode(("das:secret").getBytes())))
                .field("grant_type", "password")
                .field("username", AddressConfiguration.HIPUSERNAME)
                .field("password", AddressConfiguration.HIPPASSWORD)
                .asObject(Oauth2Token.class);
        return token;
    }

    public static HttpResponse topicMessage(String messageId,String type,String content) throws UnirestException, JsonProcessingException {
        HttpResponse<Oauth2Token>  token = getToken();
        HttpResponse<Response> response = Unirest.post(AddressConfiguration.HIPADDRESS + "/messages/topic")
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + token.getBody().getAccessToken())
                .body(MAPPER.writeValueAsString(new MessageTopic(messageId, "restful", content)))
                .asObject(Response.class);
        return response;
    }

    /**
     * 查询发送消息状态
     * @param status
     * @param startTime
     * @param endtime
     * @param token
     * @return HttpResponse
     */
    public static HttpResponse searchSendMessage(String status,String startTime,String endtime,String token) throws Exception{
        HttpResponse<MessageListResponse> response = Unirest.post(AddressConfiguration.HIPADDRESS + "/messages/send/look-up")
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + token)
                .body(MAPPER.writeValueAsString(new MessageSend(status, startTime, endtime)))
                .asObject(MessageListResponse.class);
        return response;
    }

    /**
     * 查询接收消息状态
     * @param status
     * @param startTime
     * @param endtime
     * @param token
     * @return
     * @throws Exception
     */
    public static HttpResponse searchReceiveMessage(String status,String startTime,String endtime,String token) throws Exception{
        HttpResponse<MessageListResponse> response = Unirest.post(AddressConfiguration.HIPADDRESS + "/messages/receive/look-up")
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + token)
                .body(MAPPER.writeValueAsString(new MessageSend(status, startTime, endtime)))
                .asObject(MessageListResponse.class);
        return response;
    }

    /**
     * 查询未接收的消息主体
     * @param deliverId
     * @param token
     * @return
     * @throws Exception
     */
    public static HttpResponse getMessageByDeliverId(String deliverId,String token) throws Exception{
        HttpResponse response = Unirest.get(AddressConfiguration.HIPADDRESS + "/messages/receive/"+deliverId)
                .header("Content-Type","appliction/json")
                .header("Authorization","bearer " + token)
                .asString();
        return response;
    }

    /**
     * 验证账号密码是否正确
     * @return
     * @throws UnirestException
     * @throws JsonProcessingException
     */
    public static HttpResponse getTokenByAccount(String username,String password) throws UnirestException, JsonProcessingException{
        init();
        HttpResponse<Oauth2Token> token = Unirest.post(AddressConfiguration.HIPADDRESS + "/oauth/token")
                .header("Content-Type", "application/x-www-form-urlencoded")
                .header("Authorization", "Basic " + new String(Base64.getEncoder().encode(("das:secret").getBytes())))
                .field("grant_type", "password")
                .field("username", username)
                .field("password", password)
                .asObject(Oauth2Token.class);
        return token;
    }


}
