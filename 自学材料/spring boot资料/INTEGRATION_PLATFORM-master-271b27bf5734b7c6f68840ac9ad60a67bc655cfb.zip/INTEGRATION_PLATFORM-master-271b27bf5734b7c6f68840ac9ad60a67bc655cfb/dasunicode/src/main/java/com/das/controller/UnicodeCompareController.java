package com.das.controller;

import com.das.common.result.BootstrapTableResult;
import com.das.common.result.Constant;
import com.das.domain.UnicodeCompare;
import com.das.service.UnicodeCompareService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @author zhangxi
 */
@RestController
@RequestMapping(value="/unicodeCompare")
public class UnicodeCompareController {
	
    @Autowired
    private UnicodeCompareService unicodeCompareService;

    /**
     * 查询所有的字段对比数据
     * @return
     */
    @PostMapping("listAllUnicodeCompare")
    public BootstrapTableResult listAllUnicodeCompare(Integer pageSize, Integer pageNumber, HttpServletResponse response,
                                                      HttpServletRequest request){
        PageInfo page;
        List<UnicodeCompare> unicodeCompareList;
        PageHelper.startPage(pageNumber,pageSize);
        unicodeCompareList = unicodeCompareService.listAllUniCodeCompare();
        page = new PageInfo(unicodeCompareList,5);
        int total = (int)page.getTotal();
        BootstrapTableResult bootstrapTableResult = new BootstrapTableResult(total,unicodeCompareList);
        return  bootstrapTableResult;
    }

    /**
     * 插入数据
     * @return String
     */
    @PostMapping("insertUnicodeCompare")
    public String insertUnicodeCompare(UnicodeCompare unicodeCompare){
        int count = unicodeCompareService.insertSelective(unicodeCompare);
        //unicodeCompareService.
        return Constant.SUCCESS;
    }

    /**
     * 删除数据
     * @param id
     * @return String
     */
    @PostMapping("deleteByTableName")
    public String deleteByTableName(String id){
        unicodeCompareService.deleteByTableName(id);
        return Constant.SUCCESS;
    }

    /**
     * 多条件查询数据
     * @param pageSize
     * @param pageNumber
     * @param response
     * @param request
     * @return BootstrapTableResult
     */
    @PostMapping("listUnicodeCompareByCondition")
    public BootstrapTableResult listUnicodeCompareByCondition(Integer pageSize, Integer pageNumber, HttpServletResponse response,
                                                              HttpServletRequest request){
       //获取查询条件
        String tableName = request.getParameter("tableName");
        String code = request.getParameter("code");
        String description = request.getParameter("description");
        PageInfo page;
        //封装查询条件
        UnicodeCompare unicodeCompare = new UnicodeCompare();
        unicodeCompare.setCode(code);
        unicodeCompare.setDescription(description);
        unicodeCompare.setTableName(tableName);

        PageHelper.startPage(pageNumber,pageSize);
        List<UnicodeCompare> unicodeCompareList = unicodeCompareService.listUnicodeCompareByCondition(unicodeCompare);
        page = new PageInfo(unicodeCompareList,5);
        int total = (int)page.getTotal();
        return new BootstrapTableResult(total,unicodeCompareList);
    }

    /**
     * 修改
     * @param unicodeCompare
     * @return
     */
    @PostMapping("/updateUnicodeCompare")
    public String updateUnicodeCompare(UnicodeCompare unicodeCompare){
        unicodeCompareService.updateUnicodeCompare(unicodeCompare);
        return Constant.SUCCESS;
    }
}
