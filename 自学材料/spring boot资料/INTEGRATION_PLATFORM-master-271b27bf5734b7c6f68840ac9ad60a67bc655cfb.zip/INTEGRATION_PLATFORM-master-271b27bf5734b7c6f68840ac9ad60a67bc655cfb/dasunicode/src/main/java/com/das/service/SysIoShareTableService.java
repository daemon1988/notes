package com.das.service;

import java.util.List;
import java.util.Map;

import com.das.domain.SysIoShareTable;

/**
 * @author zhangxi
 */
public interface SysIoShareTableService {
	
	 List<SysIoShareTable> listShareTable();

	/**
	 * 根据表名查询共享字典
	 */
	public SysIoShareTable  selectByPrimaryKey(String tableName);

	/**
	 * 新增数据
	 */
	public void insertSysIoShareTable(SysIoShareTable sysIoShareTable);

	/**
	 * 删除数据
	 */
	public void delTableByTableName(String tableName);

	/**
	 * 更新数据
	 */
	public void updateByPrimaryKeySelective(SysIoShareTable sysIoShareTable);

	public List<SysIoShareTable> listTableByCondition(Map map);
}
