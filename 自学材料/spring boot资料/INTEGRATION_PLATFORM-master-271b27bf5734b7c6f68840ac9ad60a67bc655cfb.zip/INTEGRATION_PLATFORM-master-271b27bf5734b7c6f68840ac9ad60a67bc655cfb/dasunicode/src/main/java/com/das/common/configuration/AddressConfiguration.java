package com.das.common.configuration;

/**
 * 接口地址配置
 * @author zhangxi
 */
public class AddressConfiguration {
    /**
     * 配置和hip同步的地址
     */
    public final static String HIPADDRESS = "http://192.168.123.233:8082/mq";

    /**
     * hip系统的账号
     */
    public final static String HIPUSERNAME = "unicode";

    /**
     * hip系统的密码
     */
    public final static String HIPPASSWORD = "unicode";

    /**
     * 单点登录系统的messageName
     */
    public final static String MESSAGE_NAME = "userToSso";
}
