package com.das.controller;

import com.das.common.result.BootstrapTableResult;
import com.das.common.result.Constant;
import com.das.domain.SysMenu;
import com.das.domain.UnicodeMessage;
import com.das.service.UnicodeMessageService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

@RestController
@RequestMapping("unicodeMessage")
public class UnicodeMessageController {
    @Autowired
    private UnicodeMessageService unicodeMessageService;

    /**
     * 列出所有数据
     * @param pageSize
     * @param pageNumber
     * @param response
     * @param request
     * @return BootstrapTableResult
     */
    @PostMapping("listAllUnicodeMessage")
    public BootstrapTableResult listAllUnicodeMessage(Integer pageSize, Integer pageNumber, HttpServletResponse response,
                                                      HttpServletRequest request){
        PageInfo page;
        List<UnicodeMessage> unicodeMessageList;
            //引入pageHelper分页插件
            //在查询之前只需要传入页码，以及每页的大小
        PageHelper.startPage(pageNumber, pageSize);
            //startPage后面紧跟的查询就是分页查询
        unicodeMessageList = unicodeMessageService.listAllUnicodeMessage();
        page = new PageInfo(unicodeMessageList, 5);
        int total = (int) page.getTotal();
        BootstrapTableResult bootstrapTableResult = new BootstrapTableResult(total, unicodeMessageList);
        return bootstrapTableResult;
    }

    /**
     * 删除数据
     */
    @PostMapping("deleteByMessageName")
    public String deleteByMessageName(String id){
        unicodeMessageService.deleteByMessageName(id);
        return Constant.SUCCESS;
    }

    /**
     * 查询数据
     */
    @PostMapping("listByMessageName")
    public BootstrapTableResult listByMessageName(Integer pageSize, Integer pageNumber, HttpServletResponse response,
                                                  HttpServletRequest request){
        PageInfo page;
        String registerMessageName  = request.getParameter("registerMessageName");
        List<UnicodeMessage> unicodeMessageList;
        PageHelper.startPage(pageNumber, pageSize);
        unicodeMessageList = unicodeMessageService.listByMessageName(registerMessageName);
        page = new PageInfo(unicodeMessageList, 5);
        int total = (int) page.getTotal();
        BootstrapTableResult bootstrapTableResult = new BootstrapTableResult(total, unicodeMessageList);
        return bootstrapTableResult;

    }

    /**
     * 插入数据
     */
    @PostMapping("insertUnicodeMessage")
    public String insertUnicodeMessage(HttpServletRequest request){
        String registerMessageName = request.getParameter("registerMessageName");
        String messageId = request.getParameter("messageId");
        UnicodeMessage unicodeMessage = new UnicodeMessage(registerMessageName,messageId);
        unicodeMessageService.insertUnicodeMessage(unicodeMessage);
        return Constant.SUCCESS;
    }


}
