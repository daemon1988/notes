package com.das.service.impl;

import com.das.dao.extend.UnicodeMessageMapperExtend;
import com.das.domain.UnicodeMessage;
import com.das.service.UnicodeCompareService;
import com.das.service.UnicodeMessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("unicodeMessageService")
public class UnicodeMessageServiceImpl implements UnicodeMessageService{
    @Autowired
    private UnicodeMessageMapperExtend unicodeMessageMapperExtend;
    @Override
    public List<UnicodeMessage> listAllUnicodeMessage() {
        return unicodeMessageMapperExtend.listAllUnicodeMessage();
    }

    /**
     * 删除数据
     * @param messageName
     * @return  List<UnicodeMessage>
     */
    @Override
    public void deleteByMessageName(String messageName) {
         unicodeMessageMapperExtend.deleteByMessageName(messageName);
    }

    @Override
    public List<UnicodeMessage> listByMessageName(String messageName) {
        return unicodeMessageMapperExtend.listByMessageName(messageName);
    }

    @Override
    public void insertUnicodeMessage(UnicodeMessage unicodeMessage) {
        unicodeMessageMapperExtend.insertUnicodeMessage(unicodeMessage);
    }
}
