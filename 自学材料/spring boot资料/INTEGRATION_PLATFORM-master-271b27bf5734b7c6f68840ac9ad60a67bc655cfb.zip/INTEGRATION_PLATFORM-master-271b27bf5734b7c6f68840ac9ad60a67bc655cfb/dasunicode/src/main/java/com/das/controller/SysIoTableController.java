package com.das.controller;

import com.das.common.result.BaseResultExtend;
import com.das.common.result.ToHipResult;
import com.das.domain.SysIoShareTable;
import com.das.domain.SysIoTable;
import com.das.service.SysIoInfService;
import com.das.service.SysIoShareTableService;
import com.das.service.SysIoTableService;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

/**
 * 注册共享字典信息
 *
 * @author zhangxi
 */
@RestController
@RequestMapping("/sysIoTable")
public class SysIoTableController {
	
    @Autowired
    private SysIoTableService sysIoTableService;

    @Autowired
    private SysIoInfService sysIoInfService;

    @Autowired
    private SysIoShareTableService sysIoShareTableService;

    /**
     * 注册共享字典信息(提供给信息交换平台)
     * @param httpEntity
     * @return
     * @throws JSONException 
     */
    @PostMapping("/outApplyCode")
    public ToHipResult outApplyCode(HttpEntity<String> httpEntity) throws JSONException{
        System.out.println("执行了没有1");
        //获取请求体
        String jsonString =  httpEntity.getBody();
        //转换成json对象
        JSONObject jsonObject = new JSONObject(jsonString);
        //获取用户名
        String ioCode = jsonObject.getString("senderId");
        //获取具体的参数
        JSONObject contentJson = new JSONObject(jsonObject.getString("content"));
        //表名
        String tableName = contentJson.getString("tableName");
        //读取权限
        String read = contentJson.getString("read");
        //写入权限
        String write = contentJson.getString("write");
        //监听权限
        String listen = contentJson.getString("listen");
        return applyCode(ioCode,tableName,read,write,listen);
    }

    /**
     * 内部接口
     * 注册共享字典信息
     *
     * @param tableName
     * @param read
     * @param write
     * @param listen
     * @return BaseResult
     */
    @PostMapping("/applyCode/{ioCode}/{tableName}/{read}/{write}/{listen}")
    public ToHipResult applyCode(@PathVariable("ioCode")String ioCode,
            @PathVariable("tableName") String tableName, @PathVariable("read") String read,
            @PathVariable("write") String write, @PathVariable("listen") String listen) {
        //判断该表是否存在
        SysIoShareTable sysIoShareTable = sysIoShareTableService.selectByPrimaryKey(tableName);
        if (sysIoShareTable == null) {
            //表名不存在时直接返回
            return new ToHipResult(41001, "表名错误，系统中无此表", null);
        } else {
            //获取该表的权限读写监听权限
            String tableRead = sysIoShareTable.getRead();
            String tableWrite = sysIoShareTable.getWrite();
            String tableListen = sysIoShareTable.getListen();

            //判断客户注册权限的格式是否正确
            Boolean readFlag = "Y".equalsIgnoreCase(read) || "N".equalsIgnoreCase(read);
            Boolean writeFlag = "Y".equalsIgnoreCase(write) || "N".equalsIgnoreCase(write);
            Boolean listenFlag = "Y".equalsIgnoreCase(listen) || "N".equalsIgnoreCase(listen);
            if (!readFlag || !writeFlag || !listenFlag) {
                return new ToHipResult(41002, "权限只能注册Y或N", null);
            }

            //校验是否能够注册该权限
            if ("Y".equalsIgnoreCase(read)) {
                if ("N".equalsIgnoreCase(tableRead)) {
                    return new ToHipResult(41002, "读取权限错误，该表只能不能注册读取权限", null);
                }
            } else if ("Y".equalsIgnoreCase(write)) {
                if ("N".equalsIgnoreCase(tableWrite)) {
                    return new ToHipResult(41002, "写入权限错误，该表只能不能注册写入权限", null);
                }
            } else if ("Y".equalsIgnoreCase(listen)) {
                if ("N".equalsIgnoreCase(tableListen)) {
                    return new ToHipResult(41002, "监听权限错误，该表只能不能注册监听权限", null);
                }
            }

            //写入权限
            Map<String, Object> queryMap = new HashMap<String, Object>();
            queryMap.put("ioCode", ioCode);
            queryMap.put("tableName", tableName);
            //注册权限时，Y表示需要获取权限，N表示不需要获取该权限，写入数据库时Y用1替代，
            // 后面审核权限的时候审核状态为1的，N的不需要审核，审核通过之后1改为Y
            if ("Y".equalsIgnoreCase(write)) {
                queryMap.put("write", "Y");
            } else {
                queryMap.put("write", "N");
            }
            if ("Y".equalsIgnoreCase(read)) {
                queryMap.put("read", "Y");
            } else {
                queryMap.put("read", "N");
            }
            if ("Y".equalsIgnoreCase(listen)) {
                queryMap.put("listen", "Y");
            } else {
                queryMap.put("listen", "N");
            }

            queryMap.put("optDate", new Date());
            sysIoTableService.insertRegistTable(queryMap);
            System.out.println("执行2");
            return new ToHipResult(0, "success", null);
        }
    }

    /**
     * 外部接口
     * 查询注册的字典有哪些已经审核完成
     * @param httpEntity
     * @return
     * @throws JSONException 
     */
    @PostMapping("/outGetAppliedCodeList")
    public ToHipResult outGetAppliedCodeList(HttpEntity<String> httpEntity) throws JSONException{
        //获取请求体
        String jsonString =  httpEntity.getBody();
        //转换成json对象
        JSONObject jsonObject = new JSONObject(jsonString);
        //获取用户名
        String ioCode = jsonObject.getString("senderId");
        return getAppliedCodeList(ioCode);
    }
    /**
     * 内部接口
     * 查询注册的字典有哪些已经审核完成
     * @param ioCode
     * @return BaseResult
     */
    @PostMapping("/getAppliedCodeList/{ioCode}")
    public ToHipResult getAppliedCodeList(@PathVariable("ioCode") String ioCode) {
        Map<String, Object> queryMap = new HashMap<String, Object>();
        //1. 获取该客户已经注册了哪些字典
        List<SysIoTable> sysIoTableList = sysIoTableService.listSysIoTableByIoCode(ioCode);
        if (sysIoTableList == null || sysIoTableList.size() == 0) {
            return new ToHipResult(0, "没有查询到数据", null);
        } else {
            BaseResultExtend baseResultExtend = new BaseResultExtend();
            baseResultExtend.setCodeSystemName("getAppliedCodeList");
            baseResultExtend.setDescription("返回已经通过审核的注册字典");
            String[] properties = {"read", "write", "listen"};
            baseResultExtend.setProperties(properties);
            List<Map> list = new ArrayList<Map>();
            for (SysIoTable sysIoTable : sysIoTableList) {
                String writeFlag = sysIoTable.getWrite();
                String readFlag = sysIoTable.getRead();
                String listenFlag = sysIoTable.getListen();
                if (!"1".equalsIgnoreCase(writeFlag)
                        && !"1".equalsIgnoreCase(readFlag)
                        && !"1".equalsIgnoreCase(listenFlag)) {
                    Map<String,Object> map = new HashMap<String,Object>();
                    map.put("code",sysIoTable.getTableName());
                    //根据code查询名称
                    SysIoShareTable sysIoShareTable = sysIoShareTableService.selectByPrimaryKey(sysIoTable.getTableName());
                    map.put("displayName",sysIoShareTable.getTableDesc());
                    map.put("read",sysIoTable.getRead());
                    map.put("write",sysIoTable.getWrite());
                    map.put("listen",sysIoTable.getListen());
                    list.add(map);
                }
            }
            baseResultExtend.setData(list);
            return new ToHipResult(0,"success",baseResultExtend);
        }
    }

}
