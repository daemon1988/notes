package com.das.service.impl;

import com.das.dao.UserTempMapper;
import com.das.domain.User;
import com.das.domain.UserTemp;
import com.das.service.UserTempService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service("userTempService")
public class UserTempServiceImpl implements UserTempService{
    @Autowired
    private UserTempMapper userTempMapper;

    /**
     * 查询所有状态为new的用户
     * @return
     */
    @Override
    public List<UserTemp> listAllUserTempWithNewStatus() {
        return userTempMapper.listAllUserTempWithNewStatus();
    }

    /**
     * 更改状态为DONE
     * @param list
     */
    @Override
    public void changeStatus(List list) {
        userTempMapper.changeStatus(list);
    }

    /**
     * 插入用户
     * @param user
     */
    @Override
    public void insertUser(User user) {
        UserTemp userTemp = new UserTemp();
        //添加临时用户表信息
        userTemp.setUsername(user.getUsername());
        userTemp.setNickname(user.getNickname());
        userTemp.setFlag("NEW");
        userTemp.setAction("INSERT");
        userTemp.setPassword(user.getPassword());
        userTemp.setTime(new Date());
        userTempMapper.insertTempUser(userTemp);
    }
}
