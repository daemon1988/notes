package com.das.service.impl;

import com.das.dao.SysIoTableMapper;
import com.das.dao.extend.SysIoTableMapperExtend;
import com.das.domain.SysIoTable;
import com.das.service.SysIoTableService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service("sysIoTableService")
public class SysIoTableServiceImpl implements SysIoTableService {
	
    private static final Logger LOGGER = LoggerFactory.getLogger(SysIoTableServiceImpl.class);
    @Autowired
    private SysIoTableMapperExtend sysIoTableMapperExtend;
    @Autowired
    private SysIoTableMapper sysIoTableMapper;

    /**
     * 注册交换的数据字典
     */
    @Transactional
    @Override
    public int insertRegistTable(Map<String, Object> queryMap) {
        try {
            return sysIoTableMapperExtend.insertRegistTable(queryMap);
        } catch (Exception e) {
            LOGGER.info("CatchException:注册数据字典时错误，" + e);
            throw e;
        }
    }

    /**
     * 交换字典注册状态查询
     */
    @Override
    public SysIoTable getSysIoTableByIoCodeAndTableName(Map<String, Object> queryMap) {
        return sysIoTableMapperExtend.getSysIoTableByIoCodeAndTableName(queryMap);
    }

    /**
     * 根据表名获取数据
     * @param tableName
     * @return List<SysIoTable>
     */
    @Override
    public List<SysIoTable> listSysIoTableByTableName(String tableName) {
        return sysIoTableMapperExtend.listSysIoTableByTableName(tableName);
    }

    /**
     * 根据ioCode查询
     * @param ioCode
     * @return
     */
    @Override
    public List<SysIoTable> listSysIoTableByIoCode(String ioCode) {
        return sysIoTableMapperExtend.listSysIoTableByIoCode(ioCode);
    }

}
