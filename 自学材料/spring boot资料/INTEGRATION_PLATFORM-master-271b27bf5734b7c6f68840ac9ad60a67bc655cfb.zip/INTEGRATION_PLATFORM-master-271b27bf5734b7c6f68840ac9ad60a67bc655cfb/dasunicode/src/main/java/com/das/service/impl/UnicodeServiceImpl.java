package com.das.service.impl;

import com.das.common.result.BaseResultExtend;
import com.das.common.result.ToHipResult;
import com.das.common.util.JdbcUtils;
import com.das.dao.SysIoShareTableMapper;
import com.das.dao.extend.UnicodeCompareMapperExtend;
import com.das.dao.extend.UnicodeMapperExtend;
import com.das.domain.SysIoShareTable;
import com.das.domain.UnicodeCompare;
import com.das.domain.UnicodeTemp;
import com.das.service.UnicodeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.util.*;

/**
 * 统一编码业务层
 * @author zhangxi
 */
@Service("unicodeService")
public class UnicodeServiceImpl implements UnicodeService {
	
    private static final Logger LOGGER = LoggerFactory.getLogger(UnicodeServiceImpl.class);
    @Autowired
    private JdbcUtils jdbcUtils;
    @Autowired
    private UnicodeMapperExtend unicodeMapperExtend;
    @Autowired
    private SysIoShareTableMapper sysIoShareTableMapper;
    @Autowired
    private UnicodeCompareMapperExtend unicodeCompareMapperExtend;

    @Override
    public ToHipResult getTableDataByTableName(String tableName) throws SQLException {
        try {
            BaseResultExtend baseResultExtend = new BaseResultExtend();

            //查询表信息
            SysIoShareTable sysIoShareTable = sysIoShareTableMapper.selectByPrimaryKey(tableName);
            if(sysIoShareTable == null ){
                return new ToHipResult(42001,"表名错误",null);
            }
            // 定义一个list集合存储属性
            Set propertiesList = new HashSet();
            // 获取两个基本属性
            UnicodeCompare unicodeCompare = unicodeCompareMapperExtend.getUnicodeCompareByTableName(tableName);

            String getDataSql = "select * from " + tableName;
            List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
            //获取表数据
            Connection con = jdbcUtils.getCon();
            Statement stat = con.createStatement();
            ResultSet rsData = stat.executeQuery(getDataSql);
            //获取结果集信息，元数据
            ResultSetMetaData rsmd = rsData.getMetaData();
            //获取列数
            int columnCount = rsmd.getColumnCount();
            //遍历结果集
            while (rsData.next()) {
                Map<String, Object> rowData = new HashMap<String, Object>();
                for (int i = 1; i <= columnCount; i++) {
                    if(!rsmd.getColumnName(i).equalsIgnoreCase(unicodeCompare.getCode())
                            && !rsmd.getColumnName(i).equalsIgnoreCase(unicodeCompare.getDescription())) {
                        propertiesList.add(rsmd.getColumnName(i));
                        rowData.put(rsmd.getColumnName(i), rsData.getObject(i));
                    }else if(!rsmd.getColumnName(i).equalsIgnoreCase(unicodeCompare.getCode())
                            && rsmd.getColumnName(i).equalsIgnoreCase(unicodeCompare.getDescription())){
                        rowData.put("displayName", rsData.getObject(i));
                    }else if(rsmd.getColumnName(i).equalsIgnoreCase(unicodeCompare.getCode())
                            && !rsmd.getColumnName(i).equalsIgnoreCase(unicodeCompare.getDescription())){
                        rowData.put("code", rsData.getObject(i));
                    }
                }
                list.add(rowData);
            }

            baseResultExtend.setCodeSystemName(tableName);
            baseResultExtend.setDescription(sysIoShareTable.getTableDesc());
            baseResultExtend.setProperties(propertiesList);
            baseResultExtend.setData(list);

            rsData.close();
            con.close();
            stat.close();
            return new ToHipResult(0,"success",baseResultExtend);
        } catch (SQLException e) {
            LOGGER.info("数据库连接失败：" + e);
            throw e;
        }catch(Exception e1){
            LOGGER.info("获取数据失败：" + e1);
            throw e1;
        }

    }

    /**
     * 获取新增的数据
     *
     * @param flag
     * @return List<UnicodeTemp>
     */
    @Override
    public List<UnicodeTemp> listTableNameByFlag(String flag) {
        return unicodeMapperExtend.listTableNameByFlag(flag);
    }

    @Override
    public void changeStatus(List list) {
        unicodeMapperExtend.changeStatus(list);
    }

    @Override
    public List<UnicodeTemp> getTableData(String tableName) {
        return  unicodeMapperExtend.getTableData(tableName);
    }

}
