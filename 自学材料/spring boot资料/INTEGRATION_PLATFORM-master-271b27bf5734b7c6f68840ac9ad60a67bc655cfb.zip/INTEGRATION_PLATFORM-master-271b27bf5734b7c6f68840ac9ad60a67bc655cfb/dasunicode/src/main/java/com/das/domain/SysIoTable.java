package com.das.domain;

import java.util.Date;

public class SysIoTable{
	
	private String ioCode;

    private String tableName;
    
    private String read;

    private String write;

    private String listen;

    private String optUser;

    private Date optDate;

    private String optTerm;

    /**
     * 状态，0表示审核通过，1表示尚未审核
     */
    private String status;
    
    public SysIoTable() {
		super();
	}

	public SysIoTable(String ioCode, String tableName, String read,
			String write, String listen, String optUser, Date optDate,
			String optTerm,String status) {
		super();
		this.ioCode = ioCode;
		this.tableName = tableName;
		this.read = read;
		this.write = write;
		this.listen = listen;
		this.optUser = optUser;
		this.optDate = optDate;
		this.optTerm = optTerm;
		this.status = status;
	}
	
	

	public String getIoCode() {
		return ioCode;
	}

	public void setIoCode(String ioCode) {
		this.ioCode = ioCode;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getRead() {
        return read;
    }

    public void setRead(String read) {
        this.read = read == null ? null : read.trim();
    }

    public String getWrite() {
        return write;
    }

    public void setWrite(String write) {
        this.write = write == null ? null : write.trim();
    }

    public String getListen() {
        return listen;
    }

    public void setListen(String listen) {
        this.listen = listen == null ? null : listen.trim();
    }

    public String getOptUser() {
        return optUser;
    }

    public void setOptUser(String optUser) {
        this.optUser = optUser == null ? null : optUser.trim();
    }

    public Date getOptDate() {
        return optDate;
    }

    public void setOptDate(Date optDate) {
        this.optDate = optDate;
    }

    public String getOptTerm() {
        return optTerm;
    }

    public void setOptTerm(String optTerm) {
        this.optTerm = optTerm == null ? null : optTerm.trim();
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "SysIoTable{" +
                "ioCode='" + ioCode + '\'' +
                ", tableName='" + tableName + '\'' +
                ", read='" + read + '\'' +
                ", write='" + write + '\'' +
                ", listen='" + listen + '\'' +
                ", optUser='" + optUser + '\'' +
                ", optDate=" + optDate +
                ", optTerm='" + optTerm + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}