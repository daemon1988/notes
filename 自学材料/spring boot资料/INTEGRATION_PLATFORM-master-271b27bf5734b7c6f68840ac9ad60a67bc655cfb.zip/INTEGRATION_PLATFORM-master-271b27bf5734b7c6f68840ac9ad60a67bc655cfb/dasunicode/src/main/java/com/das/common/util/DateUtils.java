package com.das.common.util;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 时间转换工具类
 * @author zhangxi
 */
public class DateUtils {
	
    /**
     * 长时间转换成YYYY-MM-DD hh:mm:ss格式
     * @param milliSecond
     * @return String
     */
    public static String dateToStrLong(long milliSecond){
        Date date = new Date(milliSecond);
        SimpleDateFormat sdf = new SimpleDateFormat("YYYY-MM-DD hh:mm:ss");
        return sdf.format(date);
    }
}
