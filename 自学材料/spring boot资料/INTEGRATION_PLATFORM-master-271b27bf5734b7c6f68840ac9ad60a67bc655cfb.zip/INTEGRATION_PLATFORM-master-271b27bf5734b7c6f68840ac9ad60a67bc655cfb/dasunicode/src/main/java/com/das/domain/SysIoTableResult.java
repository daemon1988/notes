package com.das.domain;

public class SysIoTableResult{
    private String read;

    private String write;

    private String listen;

	public SysIoTableResult(String read, String write, String listen) {
		super();
		this.read = read;
		this.write = write;
		this.listen = listen;
	}

	public SysIoTableResult() {
		super();
	}

	public String getRead() {
        return read;
    }

    public void setRead(String read) {
        this.read = read == null ? null : read.trim();
    }

    public String getWrite() {
        return write;
    }

    public void setWrite(String write) {
        this.write = write == null ? null : write.trim();
    }

    public String getListen() {
        return listen;
    }

    public void setListen(String listen) {
        this.listen = listen == null ? null : listen.trim();
    }

	@Override
	public String toString() {
		return "SysIoTable [read=" + read + ", write=" + write + ", listen="
				+ listen + "]";
	}


	
}