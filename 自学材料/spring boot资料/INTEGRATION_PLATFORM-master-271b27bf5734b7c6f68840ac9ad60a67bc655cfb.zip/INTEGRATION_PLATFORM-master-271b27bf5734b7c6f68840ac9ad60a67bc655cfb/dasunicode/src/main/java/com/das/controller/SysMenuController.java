package com.das.controller;

import com.das.common.result.BootstrapTableResult;
import com.das.common.result.Constant;
import com.das.domain.QueryData;
import com.das.domain.SysMenu;
import com.das.service.SysMenuService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;

/**
 * 系统菜单控制层
 * @author : zhangxi
 * @date : 2018-02-24 22:14
 */
@RestController
@RequestMapping(value = "/menu")
public class SysMenuController {
	
    private static final Logger LOGGER = LoggerFactory.getLogger(SysMenuController.class);
    @Resource
    private SysMenuService sysMenuService;

    /**
     * 查询菜单,只包括0级和1级目录
     * @return List<SysMenu>
     */
    @PostMapping(value = "/listMenu")
    public List<SysMenu> listMenu() {
        try {
            List<SysMenu> sysMenuList = sysMenuService.listMenu();
            return sysMenuList;
        } catch (Exception e) {
            LOGGER.error("CatchException:查询菜单有误", e);
            throw e;
        }
    }

    /**
     * 查询所有的目录,不限制目录等级,返回给ztree
     */
    @PostMapping(value = "/listAllMenu")
    public List<SysMenu> listAllMenu() {
        try {
            List<SysMenu> sysMenuList = sysMenuService.listNoButtonMenu();
            SysMenu sysMenu = new SysMenu();
            sysMenu.setId(0);
            sysMenu.setName("一级菜单");
            sysMenu.setParentId(-1);
            sysMenu.setOpen(true);
            sysMenuList.add(sysMenu);
            return sysMenuList;
        } catch (Exception e) {
            LOGGER.error("CatchException:", e);
            throw e;
        }
    }

    /**
     * 按条件查询目录，返回表格数据
     */
    @PostMapping(value = "/listMenuByCondition")
    public BootstrapTableResult listMenuByCondition(Integer pageSize, Integer pageNumber, HttpServletResponse response,
                                                    HttpServletRequest request) {
        try {
            //获取查询参数
            String menuName = request.getParameter("menuName");
            String parentName = request.getParameter("parentName");
            PageInfo page;
            List<SysMenu> sysMenuList;
            if (StringUtils.isBlank(menuName) && StringUtils.isBlank(parentName)) {
                //引入pageHelper分页插件
                //在查询之前只需要传入页码，以及每页的大小
                PageHelper.startPage(pageNumber, pageSize);
                //startPage后面紧跟的查询就是分页查询
                sysMenuList = sysMenuService.listMenu();
                //采用pageInfo对查询结果进行包装,只需要将pageInfo交给页面，即可获取当前页，是否有下一页等详细信息
//        new PageInfo中第二个参数表示需要连续显示的页数
                page = new PageInfo(sysMenuList, 5);
            } else {
                QueryData queryData = new QueryData();
                queryData.setStr1(menuName);
                queryData.setStr2(parentName);
                //引入pageHelper分页插件
                //在查询之前只需要传入页码，以及每页的大小
                PageHelper.startPage(pageNumber, pageSize);
                //startPage后面紧跟的查询就是分页查询
                sysMenuList = sysMenuService.listMenuByName(queryData);
                //采用pageInfo对查询结果进行包装,只需要将pageInfo交给页面，即可获取当前页，是否有下一页等详细信息
                //new PageInfo中第二个参数表示需要连续显示的页数
                page = new PageInfo(sysMenuList, 5);
            }
            int total = (int) page.getTotal();
            BootstrapTableResult bootstrapTableResult = new BootstrapTableResult(total, sysMenuList);
            return bootstrapTableResult;
        } catch (Exception e) {
            LOGGER.error("CatchException:查询菜单有误", e);
            throw e;
        }
    }

    /**
     * 保存新增菜单
     *
     * @param sysMenu
     * @return String
     */
    @PostMapping(value = "/saveNewMenu")
    public String saveNewMenu(SysMenu sysMenu) {
        try {
            sysMenuService.saveNewMenu(sysMenu);
            return Constant.SUCCESS;
        } catch (Exception e) {
            LOGGER.error("CatchException:保存新增菜单失败", e);
            throw e;
        }
    }

    /**
     * 删除菜单
     *
     * @param id
     * @return String
     */
    @PostMapping(value = "/delMenu")
    public String delMenu(String id) {
        try {
            String[] ids = id.split(",");
            //判断数组长度,如果长度为1,执行单个删除
            if (ids.length == 1) {
                sysMenuService.delMenu(Integer.valueOf(ids[0]));
            } else {
                //如果长度大于1,执行批量删除
                List<Integer> idList = new ArrayList<>();
                for (String s : ids) {
                    idList.add(Integer.valueOf("".equals(s.trim()) ? "0" : s.trim()));
                }
                sysMenuService.delMenuBatches(idList);
            }
            return Constant.SUCCESS;
        } catch (Exception e) {
            LOGGER.error("CatchException:删除菜单失败", e);
            throw e;
        }
    }

    /**
     * 更新菜单
     *
     * @param sysMenu
     * @return String
     */
    @RequestMapping(value = "/updateMenu", method = RequestMethod.POST)
    @ResponseBody
    public String updateMenu(SysMenu sysMenu) {
        try {
//            System.out.println(sysMenu.toString());
            sysMenuService.updateMenu(sysMenu);
            return Constant.SUCCESS;
        } catch (Exception e) {
            LOGGER.error("CatchException:修改菜单错误", e);
            throw e;
        }
    }
}
