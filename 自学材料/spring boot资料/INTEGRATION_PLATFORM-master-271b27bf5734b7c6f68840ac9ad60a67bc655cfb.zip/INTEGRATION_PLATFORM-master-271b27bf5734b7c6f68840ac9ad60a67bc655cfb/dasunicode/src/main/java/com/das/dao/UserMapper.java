package com.das.dao;

import com.das.domain.User;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

/**
 * 用户持久层
 * @author : zhangxi
 * @date : 2018-02-24 22:23
 */

public interface UserMapper {
	
    /**
     * 根据用户名获取用户
     * @param username
     * @return User
     */
    User getUserByUsername(String username);

    /**
     * 根据用户名和密码查找用户
     * @param map
     * @return
     */
    User getUserByUserNameAndPassword(Map map);

    /**
     * 添加用户
     * @param user
     */
    void insertSelective(User user);

    /**
     * 查询所有的用户列表
     * @return
     */
    List<User> listAllUser();

    /**
     * 修改用户
     * @param user
     */
    void updateUser(User user);

    /**
     * 按条件查询用户列表
     * @param user
     * @return  List<User>
     */
    List<User> listUserByCondition(User user);

    /**
     * 批量删除用户
     * @param list
     */
    void delUserById(List list);

    /**
     * 删除单个用户
     * @param user
     */
    void delUser(User user);
}
