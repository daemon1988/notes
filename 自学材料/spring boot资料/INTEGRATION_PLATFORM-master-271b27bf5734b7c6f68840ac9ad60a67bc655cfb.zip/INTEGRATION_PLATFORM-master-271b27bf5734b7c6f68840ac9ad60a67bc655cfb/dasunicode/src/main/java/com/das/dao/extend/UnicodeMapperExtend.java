package com.das.dao.extend;

import com.das.domain.UnicodeTemp;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

public interface UnicodeMapperExtend {
	
    /**
     * 获取新增的数据
     * @param flag
     * @return List<UnicodeTemp>
     */
    List<UnicodeTemp> listTableNameByFlag(String flag);

    /**
     * 更新状态
     */
    public void changeStatus(List list);

    /**
     * 表名
     * @param tableName
     * @return
     */
    List<UnicodeTemp>  getTableData(String tableName);


}
