package com.das.common.rest;

import java.util.List;

public class SendResponse {
    private String deliverId;
    private List receiverList;

    public SendResponse() {
    }

    public SendResponse(String deliverId, List receiverList) {
        this.deliverId = deliverId;
        this.receiverList = receiverList;
    }

    public String getDeliverId() {
        return deliverId;
    }

    public void setDeliverId(String deliverId) {
        this.deliverId = deliverId;
    }

    public List getReceiverList() {
        return receiverList;
    }

    public void setReceiverList(List receiverList) {
        this.receiverList = receiverList;
    }

    @Override
    public String toString() {
        return "SendResponse{" +
                "deliverId='" + deliverId + '\'' +
                ", receiverList=" + receiverList +
                '}';
    }
}
