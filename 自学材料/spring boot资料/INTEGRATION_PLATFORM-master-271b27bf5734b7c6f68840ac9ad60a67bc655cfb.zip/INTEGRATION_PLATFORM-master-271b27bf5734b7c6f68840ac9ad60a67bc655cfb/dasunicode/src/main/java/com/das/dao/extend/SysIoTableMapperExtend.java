package com.das.dao.extend;

import java.util.List;
import java.util.Map;

import com.das.domain.SysIoTable;
import org.apache.ibatis.annotations.Mapper;

public interface SysIoTableMapperExtend {
	
	/**
	 * 注册交换字典
	 * @param queryMap
	 * @return
	 */
	int insertRegistTable(Map<String, Object> queryMap);
	
	/**
	 * 交换字典注册状态查询
	 * @param queryMap
	 * @return SysIoTableResult
	 */
	SysIoTable getSysIoTableByIoCodeAndTableName(Map<String, Object> queryMap);

	/**
	 * 根据表名获取数据
	 * @param tableName
	 * @return List<SysIoTable>
	 */
	List<SysIoTable> listSysIoTableByTableName(String tableName);

	/**
	 * 根据ioCode查询数据
	 * @param ioCode
	 * @return
	 */
    List<SysIoTable> listSysIoTableByIoCode(String ioCode);
}
