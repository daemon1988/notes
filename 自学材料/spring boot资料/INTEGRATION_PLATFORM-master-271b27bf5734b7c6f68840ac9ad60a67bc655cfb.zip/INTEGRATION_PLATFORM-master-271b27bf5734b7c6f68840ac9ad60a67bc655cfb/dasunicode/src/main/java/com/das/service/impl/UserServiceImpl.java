package com.das.service.impl;

import com.das.common.result.Constant;
import com.das.common.util.CookieUtils;
import com.das.common.util.RedisUtils;
import com.das.common.util.UuidUtils;
import com.das.dao.UserMapper;
import com.das.domain.User;
import com.das.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author : zhangxi
 * @date : 2018-02-24 22:26
 */
@Service("userService")
public class UserServiceImpl  implements UserService {
    @Resource
    private UserMapper userMapper;
    @Autowired
    private RedisUtils redisUtils;

    @Override
    public User getUserByUsername(String username) {
        return userMapper.getUserByUsername(username);
    }

    @Override
    public String loginByUserNameAndPassword(String username, String password, HttpServletResponse response) {
        String result = "";
        Map map = new HashMap();
        map.put("username",username);
        map.put("password",password);
        User user = userMapper.getUserByUserNameAndPassword(map);
        if(user == null){

        }else{
            String token = UuidUtils.get32Uid();
            CookieUtils.setCookie(response, Constant.COOKIE_USER_TOKEN, token);
            redisUtils.put(Constant.COOKIE_USER_TOKEN, token, Constant.REDIS_EXPIRE_TIME); // user login token cache
//            redisUtils.putObj(token, user, Constant.REDIS_EXPIRE_TIME); // user login info cache
            result = "success";
        }
        return result;

    }

    /**
     * 添加新用户
     * @param user
     */
    @Override
    public void insertUser(User user) {
        //新增用户初始化设置状态为0
        Short status = 0;
        user.setStatus(status);
        //添加创建时间
        Date date = new Date();
        user.setCreateTime(date);
        //插入数据
        userMapper.insertSelective(user);
    }

    /**
     * 查询所有的用户列表
     * @return
     */
    @Override
    public List<User> listAllUser() {
        return userMapper.listAllUser();
    }

    /**
     * 修改用户
     * @param user
     */
    @Override
    public void updateUser(User user) {
        //添加修改时间
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date();
        String dateStr = sdf.format(date);
        try {
            Date myDate = sdf.parse(dateStr);
            user.setModifyTime(myDate);
            //修改用户信息
            userMapper.updateUser(user);
        } catch (ParseException e) {
            e.printStackTrace();
        }

    }

    /**
     * 按条件查询用户列表
     * @param user
     * @return List<User>
     */
    @Override
    public List<User> listUserByCondition(User user) {
        return userMapper.listUserByCondition(user);
    }

    /**
     * 批量删除用户
     * @param list
     */
    @Override
    public void delUserById(List list) {
        userMapper.delUserById(list);
    }

    /**
     * 删除单个用户
     * @param user
     */
    @Override
    public void delUser(User user) {
        userMapper.delUser(user);
    }

}
