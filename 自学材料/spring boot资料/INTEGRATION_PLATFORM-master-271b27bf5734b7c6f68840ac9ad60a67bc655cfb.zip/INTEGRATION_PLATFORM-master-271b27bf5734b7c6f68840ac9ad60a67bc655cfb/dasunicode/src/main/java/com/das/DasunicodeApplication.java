package com.das;

import com.das.common.util.SpringContextUtils;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Import;

@Import({SpringContextUtils.class})
@EnableAutoConfiguration
@MapperScan(basePackages = {"com.das.dao"})
@SpringBootApplication
public class DasunicodeApplication {
	public static void main(String[] args) {
		SpringApplication.run(DasunicodeApplication.class, args);
	}
}
