package com.das.controller;


import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 测试能否接收到信息
 * @author zhangxi
 */
@RestController
@RequestMapping("test")
public class TestController {
	
    /**
     * 测试不带参数接收
     */
    @PostMapping("/testReceive")
    public void testReceive(HttpEntity<String> httpEntity){
        System.out.println("测试接收消息："+httpEntity.getBody());
    }

    public static void main(String[] args) throws JSONException {
//        String s = "{'senderId':'unicode','deliveryId':'d7310dc6-3056-4ae4-930a-00c3321330a9','content':{'tableName':'123','write':'Y','read':'Y','listen':'Y'},'sendTime':'2018-03-31 20:00:03'}";
        String jsonStr ="{'id':'11','parentId':'root','refObj':'{'existType':'exist','deptType':'emp','treeNodeType':'dept'}'}";
        JSONObject jsonObject = new JSONObject(jsonStr);

        String senderId = jsonObject.getString("refObj");
        System.out.println(senderId);

//        JSONObject jsonObject1 = new JSONObject(jsonObject.getString("refObj"));
//        String tableName = jsonObject1.getString("existType");
//        System.out.println(tableName);

    }

   }
