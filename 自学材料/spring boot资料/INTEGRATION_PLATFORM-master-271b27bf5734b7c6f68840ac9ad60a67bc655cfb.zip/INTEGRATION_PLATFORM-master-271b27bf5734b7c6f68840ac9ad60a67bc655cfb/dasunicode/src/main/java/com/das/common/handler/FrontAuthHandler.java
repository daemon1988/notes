package com.das.common.handler;

import com.das.common.result.Constant;
import com.das.common.util.CookieUtils;
import com.das.common.util.RedisUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 自定义拦截器
 * @author zhangxi
 */

@WebServlet
public class FrontAuthHandler implements HandlerInterceptor {
    private RedisUtils redisUtils;
    @Autowired
    public FrontAuthHandler(RedisUtils redisUtils) {
        this.redisUtils = redisUtils;
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object o) throws Exception {
        // 获取访问地址
        String url = request.getRequestURI();
        String token = CookieUtils.getCookieValue(request, Constant.COOKIE_USER_TOKEN);
        // html filter
        if (StringUtils.contains(url, ".html")) {
            // login page never filter
            if (StringUtils.contains(url, "login.html")) {
                return true;
            } else {
                // whether login
                if (StringUtils.isNotBlank(token)) {
                    String key = redisUtils.get(Constant.COOKIE_USER_TOKEN);
                    if (StringUtils.isNotBlank(key)) {
                        return true;
                    }
                }
            }

            response.sendRedirect("/login.html");
            return false;
        }

        return true;
    }

    @Override
    public void postHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, ModelAndView modelAndView) throws Exception {

    }

    @Override
    public void afterCompletion(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) throws Exception {

    }
}
