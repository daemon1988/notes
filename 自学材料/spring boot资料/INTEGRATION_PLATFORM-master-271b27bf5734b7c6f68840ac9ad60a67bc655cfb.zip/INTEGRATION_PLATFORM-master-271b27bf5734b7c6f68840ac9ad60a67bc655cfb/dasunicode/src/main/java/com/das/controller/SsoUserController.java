package com.das.controller;

import com.das.common.result.SSOResult;
import com.das.common.result.ToHipResult;
import com.das.domain.User;
import com.das.service.UserService;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 单点登录
 * @author zhangxi
 */
@RestController
public class SsoUserController {
    @Autowired
    private UserService userService;
    /**
     * 单点登录接口
     * @param uid
     * @return
     */
    @PostMapping(value = "/sso-check-api/{uid}")
    public SSOResult outLogin(@PathVariable String uid) {
        return new SSOResult(0, "success", "index.html");
    }

    /**
     * 接收从单点登录系统推送的数据
     * @param httpEntity
     * @return
     * @throws JSONException 
     */
    @PostMapping("/getUserFromSso")
    public ToHipResult getUserFromSso(HttpEntity<String> httpEntity) throws JSONException{
        //获取请求json字符串
        String jsonString = httpEntity.getBody();
        System.out.println(jsonString);
//        String jsonString = "{\"senderId\":\"das-sso\",\"deliveryId\":\"e6b58405-33ca-450d-bf52-1c286e367bbd\",\"content\":\"{\\\"uid\\\":\\\"admin1\\\",\\\"userPassword\\\":\\\"000\\\",\\\"displayName\\\":\\\"111\\\",\\\"action\\\":\\\"INSERT\\\"}\",\"sendTime\":\"2018-04-08 13:51:30\"}";
//        System.out.println(jsonString1);
        JSONObject jsonObject = new JSONObject(jsonString);
        //获取请求具体数据
        JSONObject jsonObject1 = new JSONObject(jsonObject.getString("content"));
        //用户名
        String username = jsonObject1.getString("uid");
        //密码
        String password = jsonObject1.getString("userPassword");
        //昵称
        String nickName = jsonObject1.getString("displayName");
        //增删改查动作
        String action = jsonObject1.getString("action");

        User user = new User();
        user.setUsername(username);
        user.setPassword(password);
        user.setNickname(nickName);

        if("insert".equalsIgnoreCase(action)){
            //插入用户
            userService.insertUser(user);
            return new ToHipResult(0,"success","插入用户成功");
        }else if("update".equalsIgnoreCase(action)){
            //更新用户
            userService.updateUser(user);
            return new ToHipResult(0,"success","更新用户成功");
        }else{
            //删除数据
            userService.delUser(user);
            return new ToHipResult(0,"success","删除用户成功");
        }
    }
}
