package com.das.dao.extend;

import java.util.List;
import java.util.Map;

import com.das.domain.SysIoShareTable;
import org.apache.ibatis.annotations.Mapper;

public interface SysIoShareTableMapperExtend {
	/**
	 * 查找所有表
	 * @return
	 */
	List<SysIoShareTable> listShareTable();

	/**
	 * 删除表
	 */
	public void delTableByTableName(String tableName);

	/**
	 * 查询数据
	 * @param map
	 * @return List<SysIoShareTable>
	 */
	public List<SysIoShareTable> listTableByCondition(Map map);
	
}
