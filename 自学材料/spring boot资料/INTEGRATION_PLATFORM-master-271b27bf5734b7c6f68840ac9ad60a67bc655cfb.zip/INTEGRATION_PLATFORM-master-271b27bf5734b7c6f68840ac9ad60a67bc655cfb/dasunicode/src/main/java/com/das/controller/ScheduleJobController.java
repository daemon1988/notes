package com.das.controller;

import com.das.common.result.BaseResult;
import com.das.common.result.BootstrapTableResult;
import com.das.common.result.Constant;
import com.das.domain.ScheduleJob;
import com.das.service.ScheduleJobService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Date;

/**
 * 定时任务控制层
 *
 * @author : zhangxi
 * @date : 2018-02-24 21:53
 */
@RestController
@RequestMapping(value = "/scheduleJob")
public class ScheduleJobController {
	
    public static final Logger LOGGER = LoggerFactory.getLogger(ScheduleJobController.class);
    @Autowired
    private ScheduleJobService scheduleJobService;
    /**
     * 查询所有的定时任务
     *
     * @param pageSize
     * @param pageNumber
     * @return BootstrapTableResult
     */
    @RequestMapping(value = "/listAllJob", method = RequestMethod.POST)
    @ResponseBody
    public BootstrapTableResult listAllJob(int pageSize, int pageNumber) {
        BootstrapTableResult bootstrapTableResult = scheduleJobService.listAllJob(pageSize, pageNumber);
        return bootstrapTableResult;
    }
    /**
     * 暂停定时任务
     * @param jobId
     * @return BaseResult
     */
    @RequestMapping(value = "/pauseJob", method = RequestMethod.POST)
    @ResponseBody
    public BaseResult pauseJob(int jobId) {
        scheduleJobService.pauseJob(jobId);
        return new BaseResult(1, "success", "定时任务暂停成功");
    }

    /**
     * 恢复定时任务
     * @param jobId
     * @return BaseResult
     */
    @RequestMapping(value="/resumeJob",method = RequestMethod.POST)
    @ResponseBody
    public BaseResult resumeJob(int jobId){
        scheduleJobService.resumeJob(jobId);
        return new BaseResult(1, "success", "定时任务恢复成功");
    }

    /**
     * 立即执行定时任务
     * @param jobId
     * @return BaseResult
     */
    @RequestMapping(value = "/runOnce",method = RequestMethod.POST)
    @ResponseBody
    public BaseResult runOnce(int jobId){
        scheduleJobService.runOnce(jobId);
        return new BaseResult(1, "success", "立即执行定时任务成功");
    }

    /**
     * 更新时间表达式
     * @param id
     * @param cronExpression
     * @return BaseResult
     */
    @RequestMapping(value = "/updateCron",method = RequestMethod.POST)
    @ResponseBody
    public BaseResult updateCron(int id,String cronExpression){
        scheduleJobService.updateCron(id,cronExpression);
        return new BaseResult(1, "success", "更新时间表达式成功");
    }

    /**
     * 新增定时任务
     * @param scheduleJob
     * @return
     */
    @PostMapping(value="addScheduleJob")
    public String addScheduleJob(ScheduleJob scheduleJob){
        //新增定时任务默认状态为暂停
        scheduleJob.setStatus(Constant.STATUS_NOT_RUNNING);
        scheduleJobService.addScheduleJob(scheduleJob);
        return Constant.SUCCESS;
    }
}
