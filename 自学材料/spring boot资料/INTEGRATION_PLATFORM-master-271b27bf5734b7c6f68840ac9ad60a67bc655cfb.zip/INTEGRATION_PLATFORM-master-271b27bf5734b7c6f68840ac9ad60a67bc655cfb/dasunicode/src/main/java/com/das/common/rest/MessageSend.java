package com.das.common.rest;

/**
 * 发送消息
 * @author zhangxi
 */
public class MessageSend {
    private String status;
    private String startTime;
    private String endTime;

    public MessageSend() {
    }

    public MessageSend(String status, String startTime, String endTime) {
        this.status = status;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }
}
