package com.das.controller;

import com.das.common.result.ToHipResult;
import com.das.service.UnicodeService;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/unicode")
public class UnicodeController {
    public static final Logger LOGGER = LoggerFactory.getLogger(UnicodeController.class);
    @Autowired
    private UnicodeService unicodeService;

    /**
     * 根据表名获取数据
     * @param tableName
     * @return
     * @throws Exception
     */
    @PostMapping("getCodeData/{tableName}")
    public ToHipResult getCodeData(@PathVariable("tableName")String tableName) throws Exception{

        return unicodeService.getTableDataByTableName(tableName);
    }

    /**
     * 根据表名获取数据
     * @param httpEntity
     * @return
     * @throws Exception
     */
    @PostMapping("outGetCodeData")
    public ToHipResult outGetCodeData(HttpEntity<String> httpEntity) throws Exception{
        System.out.println("是否请求123");
        String jsonData = httpEntity.getBody();
        JSONObject jsonObject = new JSONObject(jsonData);
        JSONObject jsonObject1 = new JSONObject(jsonObject.getString("content"));
        String tableName = jsonObject1.getString("tableName");
        try{
            return getCodeData(tableName);
        }catch(Exception e){
            LOGGER.info("CatchException:"+e);
            throw e;
        }
    }
}
