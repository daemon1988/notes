package com.das.controller;


import com.das.common.result.*;
import com.das.common.util.CookieUtils;
import com.das.common.util.RedisUtils;
import com.das.domain.User;
import com.das.service.UserService;
import com.das.service.UserTempService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * 用户控制类
 */
@RestController
@RequestMapping("user")
public class UserController {
    @Autowired
    private UserService userService;
    @Autowired
    private RedisUtils redisUtils;
    @Autowired
    private UserTempService userTempService;

    /**
     * 单点登录接口
     * @param uid
     * @return
     */
    @PostMapping(value = "/sso-check-api/{uid}")
    public SSOResult outLogin(@PathVariable String uid) {
        return new SSOResult(0, "success", "http://192.168.117.63:8080/index.html");
    }

    /**
     * 登录
     * @param params
     * @param response
     * @return
     */
    @PostMapping("/login")
    public BaseResult login(@RequestParam HashMap<String, String> params, HttpServletResponse response) {
        String uid = params.get("uid");
        String pwd = params.get("pwd");
        if (StringUtils.isNotBlank(uid)&&StringUtils.isNotBlank(pwd)) {
            String indexUrl = userService.loginByUserNameAndPassword(uid, pwd, response);
            if (StringUtils.isNotBlank(indexUrl)) {
                return new BaseResult(0,"success","登录成功");
            } else {
                return new BaseResult(40001,"failed","账号或者密码错误");
            }
        } else {
            return new BaseResult(40002,"failed","账号密码不能为空");
        }
    }

    /**
     * 插入数据
     * @param user
     * @return
     */
    @PostMapping("insertUser")
    public String insertUser(User user){
        //插入数据
        userService.insertUser(user);
        //同时向临时表中插入数据
        userTempService.insertUser(user);
        return Constant.SUCCESS;
    }

    /**
     * 查询所有的用户列表
     * @return
     */
    @PostMapping("listAllUser")
    public BootstrapTableResult listAllUser(Integer pageSize, Integer pageNumber, HttpServletResponse response,
                                            HttpServletRequest request){
        PageInfo page;
        //设置开始页码和每页显示数量
        PageHelper.startPage(pageNumber, pageSize);
        //查询用户列表
        List<User> userList = userService.listAllUser();
        //设置连续显示的页数
        page = new PageInfo(userList,5);
        //获取总数
        int total = (int)page.getTotal();
        //返回结果
        return new BootstrapTableResult(total,userList);
    }

    /**
     * 更改用户信息
     * @param user
     * @return
     */
    @PostMapping("updateUser")
    public String updateUser(User user){
        userService.updateUser(user);
        return Constant.SUCCESS;
    }

    /**
     * 根据条件查询用户列表
     */
    @PostMapping("listUserByCondition")
    public BootstrapTableResult listUserByCondition(Integer pageSize, Integer pageNumber, HttpServletResponse response,
                                                    HttpServletRequest request){
        //获取查询条件
        String username = request.getParameter("username");
        String status = request.getParameter("status");
        User user = new User();
        user.setUsername(username);
        if(!StringUtils.isBlank(status)){
            user.setStatus(Short.valueOf(status));
        }
        PageInfo page;
        //设置开始页码和每页显示数量
        PageHelper.startPage(pageNumber, pageSize);
        //查询用户列表
        List<User> userList = userService.listUserByCondition(user);
        //设置连续显示的页数
        page = new PageInfo(userList,5);
        //获取总数
        int total = (int)page.getTotal();
        //返回结果
        return new BootstrapTableResult(total,userList);
    }

    /**
     * 删除用户
     * @param request
     * @return
     */
    @PostMapping("delUserById")
    public String delUserById(HttpServletRequest request){
        //获取参数
        String id = request.getParameter("id");
        if(id.endsWith(",")&&!",".endsWith(id)){
            id = id.substring(0,id.length()-1);
        }
        if(StringUtils.isNotBlank(id)){
            //分割成数组
            String[] ids = id.split(",");
            List<Integer> idList = new ArrayList<>();
            for (String s : ids) {
                idList.add(Integer.valueOf("".equals(s.trim()) ? "0" : s.trim()));
            }
            userService.delUserById(idList);
        }
        return Constant.SUCCESS;
    }


    /**
     * 退出系统
     * @param request
     * @return
     */
    @PostMapping("/logout")
    public String logout(HttpServletRequest request){
        String token = CookieUtils.getCookieValue(request, Constant.COOKIE_USER_TOKEN);
        if (StringUtils.isNotBlank(token)) {
            redisUtils.del(token);
        }
        return Constant.SUCCESS;
    }
}
