package com.das.dao;

import com.das.domain.SysIoTable;
import org.apache.ibatis.annotations.Mapper;


public interface SysIoTableMapper {
	
    int deleteByPrimaryKey(SysIoTable key);

    int insert(SysIoTable record);

    int insertSelective(SysIoTable record);

    SysIoTable selectByPrimaryKey(SysIoTable key);

    int updateByPrimaryKeySelective(SysIoTable record);

    int updateByPrimaryKey(SysIoTable record);
    
}