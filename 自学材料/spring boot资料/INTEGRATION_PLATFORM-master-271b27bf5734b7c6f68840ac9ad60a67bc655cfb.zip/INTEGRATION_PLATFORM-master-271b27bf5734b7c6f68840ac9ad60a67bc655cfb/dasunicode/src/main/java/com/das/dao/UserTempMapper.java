package com.das.dao;

import com.das.domain.UserTemp;

import java.util.List;

/**
 * @author zhangxi
 */
public interface UserTempMapper {
    /**
     * 查询所有新增状态的用户
     * @return
     */
    List<UserTemp> listAllUserTempWithNewStatus();

    /**
     * 更改状态为DONE
     * @param list
     */
    void changeStatus(List list);

    /**
     * 向用户临时表插入数据
     */
    void insertTempUser(UserTemp userTemp);
}
