package com.das.dao.extend;

import com.das.domain.UnicodeCompare;

import java.util.List;

/**
 * @author zhangxi
 */
public interface UnicodeCompareMapperExtend {
	
   /**
    * 根据表名查询数据
    * @param tableName
    * @return UnicodeCompare
    */
   UnicodeCompare getUnicodeCompareByTableName(String tableName);

   /**
    * 查询所有数据
    */
   List<UnicodeCompare> listAllUniCodeCompare();

   /**
    * 删除数据
    */
   public void deleteByTableName(String tableName);

   /**
    * 多条件查询
    * @param unicodeCompare
    * @return List<UnicodeCompare>
    */
   public List<UnicodeCompare> listUnicodeCompareByCondition(UnicodeCompare unicodeCompare);

   void updateUnicodeCompare(UnicodeCompare unicodeCompare);
}
