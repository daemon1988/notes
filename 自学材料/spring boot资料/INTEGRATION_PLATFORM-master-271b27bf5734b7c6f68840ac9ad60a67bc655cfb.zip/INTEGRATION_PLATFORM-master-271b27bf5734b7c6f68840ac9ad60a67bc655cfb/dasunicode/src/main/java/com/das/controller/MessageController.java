package com.das.controller;

import com.das.common.rest.*;
import com.das.common.result.BaseResult;
import com.das.common.result.BootstrapTableResult;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("message")
public class MessageController {
	private static final Logger LOGGER = LoggerFactory.getLogger(MessageController.class);

    //验证账号密码
    @PostMapping("verifyAccount")
    public BaseResult verifyAccount(String username,String password){
        try {
            System.out.println("username:"+username);
            System.out.println("password:"+password);
            //验证账号密码是否正确
            HttpResponse<Oauth2Token> token = RestUtil.getTokenByAccount(username,password);
            if(StringUtils.isNotBlank(token.getBody().getAccessToken())){
                return new BaseResult(0,"success",token.getBody().getAccessToken());
            }else{
                return new BaseResult(40001,"failed","获取token错误");
            }
        }catch(UnirestException e){
            return new BaseResult(40001,"failed","账号密码错误");
        }catch (Exception e){
            return new BaseResult(40000,"failed","服务器内部错误");
        }
    }

    /**
     * 查询发送消息
     * @param response
     * @param request
     * @param status
     * @param startTime
     * @param endTime
     * @param token
     * @return
     */
    @PostMapping("searchSendMessage/{status}/{startTime}/{endTime}/{token}")
    public BootstrapTableResult searchSendMessage(HttpServletResponse response, HttpServletRequest request,
                                                  @PathVariable("status")String status,@PathVariable("startTime")String startTime,
                                                  @PathVariable("endTime")String endTime,@PathVariable("token")String token){
        try {
            HttpResponse<MessageListResponse> httpResponse = RestUtil.searchSendMessage(status, startTime, endTime, token);
            if("0".equals(httpResponse.getBody().getResponseCode())){
                List<SendResponse> list = httpResponse.getBody().getMessageList();
                return new BootstrapTableResult(list.size(),list);
            }else{
                return new BootstrapTableResult(0,null);
            }
        }catch(Exception e){
            LOGGER.error("CatchException:查询消息状态错误"+e);
            return new BootstrapTableResult(0,null);
        }
    }

    /**
     * 查询消息接收状态
     * @param response
     * @param request
     * @param status
     * @param startTime
     * @param endTime
     * @param token
     * @return
     */
    @PostMapping("searchReceiveMessage/{status}/{startTime}/{endTime}/{token}")
    public BootstrapTableResult searchReceiveMessage(HttpServletResponse response, HttpServletRequest request,
                                                  @PathVariable("status")String status,@PathVariable("startTime")String startTime,
                                                  @PathVariable("endTime")String endTime,@PathVariable("token")String token){
        try {
            HttpResponse<MessageListResponse> httpResponse = RestUtil.searchReceiveMessage(status, startTime, endTime, token);
            if("0".equals(httpResponse.getBody().getResponseCode())){
                List list = httpResponse.getBody().getMessageList();
                return new BootstrapTableResult(list.size(),list);
            }else{
                return new BootstrapTableResult(0,null);
            }
        }catch(Exception e){
            LOGGER.error("CatchException:查询消息状态错误"+e);
            return new BootstrapTableResult(0,null);
        }
    }

    /**
     * 获取消息主题
     * @param request
     * @return
     * @throws Exception
     */
    @PostMapping("getMessage")
    public BaseResult getMessage(HttpServletRequest request) throws Exception{
        //获取查询条件
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String deliverId = request.getParameter("deliverId");
        //验证账号密码是否正确
        BaseResult baseResult = verifyAccount(username,password);
        //如果账号密码正确
        if(baseResult.getCodeMessage() == 0){
            //根据deliverId查询消息主题
            HttpResponse response = RestUtil.getMessageByDeliverId(deliverId, (String)baseResult.getData());
            return new BaseResult(0,"success",response.getBody());
        }else{
            return baseResult;
        }
    }
}
