package com.das.service.impl;

import com.das.dao.SysMenuMapper;
import com.das.domain.QueryData;
import com.das.domain.SysMenu;
import com.das.service.SysMenuService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author : zhangxi
 * @date : 2018-02-24 22:28
 */
@Service("sysMenuService")
public class SysMenuServiceImpl implements SysMenuService{
	
    @Resource
    private SysMenuMapper sysMenuMapper;

    @Override
    public List<SysMenu> listMenu() {
        return sysMenuMapper.listMenu();
    }

    /**
     * 新增菜单/目录/按钮
     * @param sysMenu
     */
    @Override
    public void saveNewMenu(SysMenu sysMenu) {
        sysMenuMapper.saveNewMenu(sysMenu);
    }

    /**
     * 查询目录(不包括按钮)
     * @Return List<SysMenu>
     */
    @Override
    public List<SysMenu> listNoButtonMenu() {
        return sysMenuMapper.listNoButtonMenu();
    }

    /**
     * 删除单个菜单
     * @param id
     */
    @Override
    public void delMenu(Integer id) {
        sysMenuMapper.delMenu(id);
    }

    /**
     * 批量删除菜单
     * @param idList
     */
    @Override
    public void delMenuBatches(List<Integer> idList) {
        sysMenuMapper.delMenuBatches(idList);
    }

    /**
     * 更新菜单
     * @param sysMenu
     */
    @Override
    public void updateMenu(SysMenu sysMenu) {
        sysMenuMapper.updateMenu(sysMenu);
    }

    /**
     * 根据菜单名称和上级菜单名称查询列表
     * @param queryData
     * @return public List<SysMenu>
     */
    @Override
    public List<SysMenu> listMenuByName(QueryData queryData) {
        return sysMenuMapper.listMenuByName(queryData);
    }


}
