package com.das.service;

import com.das.common.result.BootstrapTableResult;
import com.das.domain.ScheduleJob;

/**
 * 定时任务业务层
 * @author : zhangxi
 * @date : 2018-02-24 22:26
 */
public interface ScheduleJobService {
	
    /**
     * 查询所有的定时任务
     * @return List<ScheduleJob>
     */
    BootstrapTableResult listAllJob(int pageSize, int pageNumber);

    /**
     * 暂停定时任务
     * @param jobId
     */
    void pauseJob(int jobId);

    /**
     * 恢复一个定时任务
     * @param jobId
     */
    void resumeJob(int jobId);

    /**
     * 立即执行一个定时任务
     * @param jobId
     */
    void runOnce(int jobId);

    /**
     * 更新时间表达式
     * @param id
     * @param cronExpression
     */
    void updateCron(int id, String cronExpression);

    /**
     * 新增定时任务
     * @param scheduleJob
     */
    void addScheduleJob(ScheduleJob scheduleJob);
}
