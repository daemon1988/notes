package com.das.service;

import java.sql.SQLException;
public interface TriggerService {
    /**
     * 插入触发器
     * @param context
     */
   void insertTrigger(String context) throws SQLException;
}
