package com.das.domain;

import java.util.Date;

public class SysIoInf {
	
    private String ioCode;

    private String chnDesc;

    private String engDesc;

    private String contactsName;

    private String tel;

    private String eMail;

    private String password;

    private String status;

    private String py1;

    private String py2;

    private String optUser;

    private Date optDate;

    private String optTerm;

    public String getIoCode() {
        return ioCode;
    }

    public void setIoCode(String ioCode) {
        this.ioCode = ioCode == null ? null : ioCode.trim();
    }

    public String getChnDesc() {
        return chnDesc;
    }

    public void setChnDesc(String chnDesc) {
        this.chnDesc = chnDesc == null ? null : chnDesc.trim();
    }

    public String getEngDesc() {
        return engDesc;
    }

    public void setEngDesc(String engDesc) {
        this.engDesc = engDesc == null ? null : engDesc.trim();
    }

    public String getContactsName() {
        return contactsName;
    }

    public void setContactsName(String contactsName) {
        this.contactsName = contactsName == null ? null : contactsName.trim();
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel == null ? null : tel.trim();
    }

    public String geteMail() {
        return eMail;
    }

    public void seteMail(String eMail) {
        this.eMail = eMail == null ? null : eMail.trim();
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password == null ? null : password.trim();
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }

    public String getPy1() {
        return py1;
    }

    public void setPy1(String py1) {
        this.py1 = py1 == null ? null : py1.trim();
    }

    public String getPy2() {
        return py2;
    }

    public void setPy2(String py2) {
        this.py2 = py2 == null ? null : py2.trim();
    }

    public String getOptUser() {
        return optUser;
    }

    public void setOptUser(String optUser) {
        this.optUser = optUser == null ? null : optUser.trim();
    }

    public Date getOptDate() {
        return optDate;
    }

    public void setOptDate(Date optDate) {
        this.optDate = optDate;
    }

    public String getOptTerm() {
        return optTerm;
    }

    public void setOptTerm(String optTerm) {
        this.optTerm = optTerm == null ? null : optTerm.trim();
    }
}