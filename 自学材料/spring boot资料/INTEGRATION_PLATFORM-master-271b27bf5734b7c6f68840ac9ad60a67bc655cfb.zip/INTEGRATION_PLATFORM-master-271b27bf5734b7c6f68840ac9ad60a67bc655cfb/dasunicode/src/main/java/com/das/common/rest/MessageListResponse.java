package com.das.common.rest;

import java.util.List;

public class MessageListResponse {
    private String responseCode;
    private List messageList;

    public MessageListResponse() {
    }

    public MessageListResponse(String responseCode, List messageList) {
        this.responseCode = responseCode;
        this.messageList = messageList;
    }

    public String getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(String responseCode) {
        this.responseCode = responseCode;
    }

    public List getMessageList() {
        return messageList;
    }

    public void setMessageList(List messageList) {
        this.messageList = messageList;
    }
}
