package com.das.common.result;

/**
 * 客户主动请求时返回给HIP消息平台的结果集
 * @author zhangxi
 */
public class ToHipResult {
	
    /**
     * 状态码：0成功，其余为失败
     */
    private int responseCode;
    /**
     * 成功时为success，失败时描述具体原因
     */
    private String responseMessage;

    /**
     * 详细数据
     */
    private Object content;

    public ToHipResult() {
    }

    public ToHipResult(int responseCode, String responseMessage, Object content) {
        this.responseCode = responseCode;
        this.responseMessage = responseMessage;
        this.content = content;
    }

    public int getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(int responseCode) {
        this.responseCode = responseCode;
    }

    public String getResponseMessage() {
        return responseMessage;
    }

    public void setResponseMessage(String responseMessage) {
        this.responseMessage = responseMessage;
    }

    public Object getContent() {
        return content;
    }

    public void setContent(Object content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return "ToHipResult{" +
                "responseCode=" + responseCode +
                ", responseMessage='" + responseMessage + '\'' +
                ", content=" + content +
                '}';
    }
}
