package com.das.service.impl;

import com.das.dao.UnicodeCompareMapper;
import com.das.dao.extend.UnicodeCompareMapperExtend;
import com.das.domain.UnicodeCompare;
import com.das.service.UnicodeCompareService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("unicodeCompareService")
public class UnicodeCompareServiceImpl implements UnicodeCompareService{
	
    @Autowired
    private UnicodeCompareMapperExtend unicodeCompareMapperExtend;
    @Autowired
    private UnicodeCompareMapper unicodeCompareMapper;

    /**
     * 根据表名查询数据
     * @param tableName
     * @return UnicodeCompare
     */
    @Override
    public UnicodeCompare getUnicodeCompareByTableName(String tableName) {
        return unicodeCompareMapperExtend.getUnicodeCompareByTableName(tableName);
    }

    /**
     * 查询所有数据
     * @return List<UnicodeCompare>
     */
    @Override
    public List<UnicodeCompare> listAllUniCodeCompare() {
        return unicodeCompareMapperExtend.listAllUniCodeCompare();
    }

    /**
     * 插入数据
     * @param unicodeCompare
     * @return
     */
    @Override
    public int insertSelective(UnicodeCompare unicodeCompare) {
        return unicodeCompareMapper.insertSelective(unicodeCompare);
    }

    /**
     * 删除数据
     * @param tableName
     */
    @Override
    public void deleteByTableName(String tableName) {
        unicodeCompareMapperExtend.deleteByTableName(tableName);
    }

    /**
     * 多条件查询
     * @param unicodeCompare
     * @return List<UnicodeCompare>
     */
    @Override
    public List<UnicodeCompare> listUnicodeCompareByCondition(UnicodeCompare unicodeCompare) {
        return unicodeCompareMapperExtend.listUnicodeCompareByCondition(unicodeCompare);
    }

    /**
     * 修改
     * @param unicodeCompare
     * @return
     */
    @Override
    public void updateUnicodeCompare(UnicodeCompare unicodeCompare) {
        unicodeCompareMapperExtend.updateUnicodeCompare(unicodeCompare);
    }


}
