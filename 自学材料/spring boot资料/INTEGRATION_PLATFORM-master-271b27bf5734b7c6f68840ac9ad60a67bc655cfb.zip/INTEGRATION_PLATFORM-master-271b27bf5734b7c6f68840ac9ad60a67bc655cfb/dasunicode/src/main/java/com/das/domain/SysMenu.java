package com.das.domain;

/**
 * 菜单实体类
 * @author : zhangxi
 * @date : 2018-02-24 21:36
 */
public class SysMenu {
	
    private Integer id;
    /**
     * 菜单名称
     */
    private String name;
    /**
     * 菜单类型，0表示目录，1表示菜单，2表示按钮
     */
    private Integer type;
    /**
     * 上一级菜单id
     */
    private Integer parentId;
    /**
     * 排序
     */
    private Integer orderNum;
    /**
     * 菜单url地址
     */
    private String url;
    /**
     * 菜单图标
     */
    private String icon;
    /**
     * ztree属性
     */
    private Boolean open;

    /**
     * 上级菜单名称
     */
    private String parentName;

    public SysMenu(Integer id, String name, Integer type, Integer parentId, Integer orderNum, String url, String icon, Boolean open, String parentName) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.parentId = parentId;
        this.orderNum = orderNum;
        this.url = url;
        this.icon = icon;
        this.open = open;
        this.parentName = parentName;
    }

    public SysMenu() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    public Integer getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(Integer orderNum) {
        this.orderNum = orderNum;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public Boolean getOpen() {
        return open;
    }

    public void setOpen(Boolean open) {
        this.open = open;
    }

    public String getParentName() {
        return parentName;
    }

    public void setParentName(String parentName) {
        this.parentName = parentName;
    }

    @Override
    public String toString() {
        return "SysMenu{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", type=" + type +
                ", parentId=" + parentId +
                ", orderNum=" + orderNum +
                ", url='" + url + '\'' +
                ", icon='" + icon + '\'' +
                ", open=" + open +
                ", parentName='" + parentName + '\'' +
                '}';
    }
}
