package com.das.schedule;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.scheduling.quartz.QuartzJobBean;

/**
 * @author : zhangxi
 * @date : 2018-02-24 22:33
 */
public class ScheduleJobDetails extends QuartzJobBean {
	
    @Override
    protected void executeInternal(JobExecutionContext jobExecutionContext) throws JobExecutionException {

    }
}
