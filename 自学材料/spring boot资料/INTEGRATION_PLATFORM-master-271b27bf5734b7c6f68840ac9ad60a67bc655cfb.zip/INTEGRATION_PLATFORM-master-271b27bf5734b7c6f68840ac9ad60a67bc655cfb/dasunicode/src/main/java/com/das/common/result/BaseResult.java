package com.das.common.result;

/**
 * 统一返回结果类
 *
 * @author : zhangxi
 * @date : 2018-02-24 21:58
 */
public class BaseResult {
	
    /**
     * 数据结果集
     */
    public Object data;
    /**
     * 状态码：0成功，其他为失败
     */
    private int codeMessage;
    /**
     * 成功为success，其他为失败原因
     */
    private String message;


    public BaseResult() {
        super();
    }

    public BaseResult( int codeMessage, String message,Object data) {
        this.data = data;
        this.codeMessage = codeMessage;
        this.message = message;
    }


    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public int getCodeMessage() {
        return codeMessage;
    }

    public void setCodeMessage(int codeMessage) {
        this.codeMessage = codeMessage;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}
