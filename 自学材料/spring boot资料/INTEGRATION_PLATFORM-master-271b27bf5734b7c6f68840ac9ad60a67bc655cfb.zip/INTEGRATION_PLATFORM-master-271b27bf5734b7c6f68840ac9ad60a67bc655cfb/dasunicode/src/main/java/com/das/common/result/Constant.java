package com.das.common.result;

/**
 * 系统常量
 * @author : zhangxi
 * @date : 2018-02-24 22:04
 */
public class Constant {
	
    /**
     * 成功
     */
    public static final String SUCCESS = "success";
    /**
     * 错误
     */
    public static final String FALSE = "false";

    /**
     * 失败
     */
    public static final String FAILED = "failed";
    /**
     * 空值
     */
    public static final String NULL = "null";
    /**
     * 分页条显示页数，设置的默认值是5
     */
    public static final int PAGENUMBER = 5;
    /**
     * 定时任务启动状态
     */
    public static final int STATUS_RUNNING = 0;
    /**
     * 定时任务暂停状态
     */
    public static final int STATUS_NOT_RUNNING = 1;

    /**
     * cookie信息
     */
    public final static String COOKIE_USER_TOKEN = "token";

    /**
     * 登录过期时间
     */
    public final static int REDIS_EXPIRE_TIME = 1800;
    /**
     * 定时任务状态
     *
     * @author adminstrator
     * @date 2017-11-21 下午 13:40
     */
    public enum ScheduleStatus {
        /**
         * 正常
         */
        NORMAL(0),
        /**
         * 暂停
         */
        PAUSE(1);
        private int value;

        private ScheduleStatus(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }
    }
}
