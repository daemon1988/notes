package com.das.service;

import com.das.domain.UnicodeMessage;

import java.util.List;

public interface UnicodeMessageService {
    /**
     * 查询所有的消息
     *
     * @return
     */
    List<UnicodeMessage> listAllUnicodeMessage();

    /**
     * 删除数据
     */
   void deleteByMessageName(String messageName);

    /**
     * 查询数据
     */
    List<UnicodeMessage> listByMessageName(String messageName);

    /**
     * 插入数据
     */
    void insertUnicodeMessage(UnicodeMessage unicodeMessage);

}