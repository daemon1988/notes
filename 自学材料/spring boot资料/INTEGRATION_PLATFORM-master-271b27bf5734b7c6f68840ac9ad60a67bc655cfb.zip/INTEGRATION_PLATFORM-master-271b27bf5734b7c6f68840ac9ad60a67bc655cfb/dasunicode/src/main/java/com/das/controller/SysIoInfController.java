package com.das.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.das.common.result.BaseResult;
import com.das.common.result.BootstrapTableResult;
import com.das.domain.SysIoInf;
import com.das.service.SysIoInfService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

/**
 * 子系统操作Controller
 */
@RestController
@RequestMapping("/sysIoInf")
public class SysIoInfController {
	
	public static final Logger LOGGER = LoggerFactory.getLogger(SysIoInf.class);
    @Autowired
    private SysIoInfService sysIoInfService;

    /**
     * 子系统注册内部接口
     *
     * @param request
     * @param response
     * @return BaseResult
     */
    @PostMapping("/register")
    public BaseResult register(HttpServletRequest request, HttpServletResponse response) {
    	SysIoInf sysIoInf = packingSysIoInf(request);
        return outerRegister(sysIoInf);
    }

    /**
     * 子系统注册外部接口
     * @return BaseResult
     */
    @PostMapping("/outerRegister")
    public BaseResult outerRegister(SysIoInf sysIoInf) {
    	sysIoInf.setOptDate(new Date());
    	//新增子系统默认状态为NEW
    	sysIoInf.setStatus("NEW");
        try {
            if (sysIoInf.getIoCode() != null && !"".equals(sysIoInf.getIoCode())) {
                if (sysIoInfService.selectByIoCode(sysIoInf.getIoCode()) != null) {
                    return new BaseResult(20001, "failed", "该子系统已存在");
                } else {
                	sysIoInfService.saveMessage(sysIoInf);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return new BaseResult(20003, "failed", "注册异常");
        }
        return new BaseResult(20004, "success", "子系统注册成功");
	}

    /**
     * 修改子系统的注册状态
     *
     * @param request
     * @param response
     * @param ioCode
     * @param status
     * @return
     */
    @PostMapping("/verify/{ioCode}/{status}")
    public BaseResult verify(HttpServletRequest request, HttpServletResponse response, @PathVariable("ioCode")String ioCode, @PathVariable("status")String status) {
        SysIoInf sysIoInf = new SysIoInf();
        sysIoInf.setIoCode(ioCode);
        sysIoInf.setStatus(status);
        sysIoInf.setOptDate(new Date());
        sysIoInf.setOptUser("yuanqs");
        if (sysIoInfService.updateStatusByCode(sysIoInf) == 0) {
            return new BaseResult(1, "failed", "修改子系统状态失败");
        }
        return new BaseResult(1, "success", "修改子系统状态成功");
    }

    /**
     * 修改密码
     *
     * @param request
     * @param response
     * @param ioCode
     * @param oldPassword
     * @param newPassword
     * @return BaseResult
     */
    @PostMapping("/updatePassword/{ioCode}/{oldPassword}/{newPassword}")
    public BaseResult updatePassword(HttpServletRequest request, HttpServletResponse response, @PathVariable("ioCode")String ioCode,
    		@PathVariable("oldPassword")String oldPassword, @PathVariable("newPassword")String newPassword) {
        Map<String, Object> queryMap = new HashMap<String, Object>();
        queryMap.put("ioCode", ioCode);
        queryMap.put("password", oldPassword);
        SysIoInf sysIoInf = sysIoInfService.selectByIoCodePassword(queryMap);
        if (sysIoInf != null) {
            queryMap.put("password", newPassword);
            sysIoInfService.updatePasswordByPrimaryKey(queryMap);
            return new BaseResult(21007, "success", "修改密码成功");
        }
        return new BaseResult(21006, "fail", "修改密码失败");
    }

    /**
     * 查询所有的注册子系统
     *
     * @return
     */
    @PostMapping("/listAllSysIoInf")
    public BootstrapTableResult listAllSysIoInf(Integer pageSize, Integer pageNumber, HttpServletResponse response,
                                                 HttpServletRequest request) {
        try {
            PageHelper.startPage(pageNumber, pageSize);
            List<SysIoInf> sysIoInfList = sysIoInfService.listAllSysIoInf();
            PageInfo page = new PageInfo(sysIoInfList, 5);
            //总记录数
            int total = (int) page.getTotal();
            BootstrapTableResult bootstrapTableResult = new BootstrapTableResult(total, sysIoInfList);
            return bootstrapTableResult;
        } catch (Exception e) {
             LOGGER.error("CatchException:获取注册子系统错误", e);
            throw e;
        }
    }
    /**
     * 更新子系统信息
     * @param request
     * @param response
     * @return
     */
    @PostMapping("/updateSysIoInf")
    public BaseResult updateSysIoInf(HttpServletRequest request,HttpServletResponse response){
    	try{
	    	SysIoInf sysIoInf = packingSysIoInf(request);
	    	//清空密码
	    	sysIoInf.setPassword(null);
	    	//调用service更新子系统信息方法
	    	int num = sysIoInfService.updateByPrimaryKeySelective(sysIoInf);
	    	if(num==1){
	    		return new BaseResult(0, "success", "更新子系统信息成功");
	    	}else{
	    		return new BaseResult(1, "failed", "更新子系统信息错误");
	    	}
    	}catch(Exception e){
    		LOGGER.info("catchException：更新子系统信息错误，"+e);
    		throw e;
    	}
    }
    /**
     * 根据子系统编码查询注册状态
     * @return
     */
    @GetMapping("/getStatusByIoCode/{ioCode}")
    public BaseResult getStatusByIoCode(@PathVariable("ioCode")String ioCode){
    	//根据编码查询子系统
    	SysIoInf sysIoInf = sysIoInfService.selectByIoCode(ioCode);
        //new表示新增子系统
        String newResult = "NEW";
        //enabled有效的子系统
        String enabledResult = "ENABLED";
        //disabled无效的子系统
        String disabledResult = "DISABLED";
    	//判断子系统是否存在
    	if(sysIoInfService.selectByIoCode(ioCode) == null){
    		//返回不存在
    		return new BaseResult(21001,"failed","子系统不存在");
    	}else{
    		if(newResult.equals(sysIoInf.getStatus())){
    			//新增子系统
    			return new BaseResult(21002,"NEW","新增子系统");
    		}else if(enabledResult.equals(sysIoInf.getStatus())){
    			//有效的子系统
    			return new BaseResult(21003,"ENABLED","有效的子系统");
    		}else{
    			//无效的子系统
    			return new BaseResult(21004,"DISABLED","无效的子系统");
    		}
    	}
    }
    /**
     * 按条件查找子系统
     * @param request
     * @param response
     * @return BootstrapTableResult
     */
    @PostMapping("/listSysIoInfByCondition")
    public BootstrapTableResult listSysIoInfByCondition(Integer pageSize, Integer pageNumber,HttpServletRequest request,HttpServletResponse response){
    	SysIoInf sysIoInf = new SysIoInf();
    	String ioCode = request.getParameter("ioCode");
    	String chnDesc = request.getParameter("chnDesc");
    	String status = request.getParameter("status");

    	sysIoInf.setIoCode(ioCode);
    	sysIoInf.setChnDesc(chnDesc);
    	List<SysIoInf> sysIoInfList = new ArrayList<SysIoInf>();

    	if(!StringUtils.isBlank(status)){
    		sysIoInf.setStatus(status);
    		PageHelper.startPage(pageNumber, pageSize);
    		sysIoInfList = sysIoInfService.listSysIoInfByCondition(sysIoInf);
    	}else{
    		PageHelper.startPage(pageNumber, pageSize);
    		sysIoInfList = sysIoInfService.listSysIoInfByCondition(sysIoInf);
    	}
    	PageInfo page = new PageInfo(sysIoInfList, 5);
        //总记录数
        int total = (int) page.getTotal();
        BootstrapTableResult bootstrapTableResult = new BootstrapTableResult(total, sysIoInfList);
        return bootstrapTableResult;

    }


    /**
     * 获取request中的参数，封装成SysIoInf对象
     * @param request
     * @return SysIoInf
     */

	private SysIoInf packingSysIoInf(HttpServletRequest request) {
		//获取前端传递过来的参数
    	String code = request.getParameter("ioCode");
    	String chnDesc = request.getParameter("chnDesc");
    	String engDesc = request.getParameter("engDesc");
    	String contactsName = request.getParameter("contactsName");
    	String tel = request.getParameter("tel");
    	String eMail = request.getParameter("eMail");
    	String password = request.getParameter("password");
    	String py1 = request.getParameter("py1");
    	String py2 = request.getParameter("py2");

    	//封装到UnicodeSubsystem对象中
    	SysIoInf sysIoInf = new SysIoInf();
    	sysIoInf.setIoCode(code);
    	sysIoInf.setChnDesc(chnDesc);
    	sysIoInf.setEngDesc(engDesc);
    	sysIoInf.setContactsName(contactsName);
    	sysIoInf.setTel(tel);
    	sysIoInf.seteMail(eMail);
    	sysIoInf.setPassword(password);
    	sysIoInf.setPy1(py1);
    	sysIoInf.setPy2(py2);
    	return sysIoInf;
	}

}
