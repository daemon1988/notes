package com.das.domain;

import java.util.Date;

public class UserTemp {
    private String username;
    private String password;
    private String nickname;
    private String flag;
    private String action;
    private Date time;

    public UserTemp() {
    }

    public UserTemp(String username, String password, String nickname, String flag, String action, Date time) {
        this.username = username;
        this.password = password;
        this.nickname = nickname;
        this.flag = flag;
        this.action = action;
        this.time = time;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    @Override
    public String toString() {
        return "UserTemp{" +
                "username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", nickname='" + nickname + '\'' +
                ", flag='" + flag + '\'' +
                ", action='" + action + '\'' +
                ", time=" + time +
                '}';
    }
}
