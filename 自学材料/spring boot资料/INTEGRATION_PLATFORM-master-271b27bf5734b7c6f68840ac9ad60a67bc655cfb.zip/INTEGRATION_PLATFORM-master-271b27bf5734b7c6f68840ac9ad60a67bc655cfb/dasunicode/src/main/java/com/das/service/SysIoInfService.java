package com.das.service;

import java.util.List;
import java.util.Map;

import com.das.domain.SysIoInf;
import com.das.domain.SysIoTableResult;

/**
 * 子系统Service
 */
public interface SysIoInfService {
	
	/**
     * 保存子系统的注册信息
     * @param sysIoInf
     */
    void saveMessage(SysIoInf sysIoInf);

    /**
     * 更新子系统的注册信息
     * @param sysIoInf
     */
    void updateMessage(SysIoInf sysIoInf);

    /**
     * 通过系统代码查询
     * @param ioCode
     */
    SysIoInf selectByIoCode(String ioCode);

    /**
     * 修改子系统的状态
     * @param sysIoInf
     * @return
     */
    int updateStatusByCode(SysIoInf sysIoInf);

    /**
     * 根据code和password查询子系统信息
     * @param map
     * @return
     */
    SysIoInf selectByIoCodePassword(Map<String, Object> map);

    /**
     * 更新子系统密码
     * @param map
     * @return
     */
    int updatePasswordByPrimaryKey(Map<String, Object> map);

    /**
     * 查询所有子系统
     * @return
     */
    List<SysIoInf> listAllSysIoInf();

    /**
     * 更新子信息系统信息
     * @param sysIoInf
     */
	int updateByPrimaryKeySelective(SysIoInf sysIoInf);
	
	/**
	 * 根据条件查询子系统
	 * @param sysIoInf
	 * @return
	 */
	List<SysIoInf> listSysIoInfByCondition(SysIoInf sysIoInf);

	
}
