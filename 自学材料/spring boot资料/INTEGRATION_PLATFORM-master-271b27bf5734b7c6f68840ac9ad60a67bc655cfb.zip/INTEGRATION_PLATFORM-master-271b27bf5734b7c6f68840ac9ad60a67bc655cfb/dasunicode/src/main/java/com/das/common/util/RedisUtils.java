package com.das.common.util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.*;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * redis工具类
 * @author zhangxi
 */
@Component
public class RedisUtils {
	
    private StringRedisTemplate stringRedisTemplate;
    private RedisTemplate redisTemplate;
    @Autowired
    RedisUtils(StringRedisTemplate stringRedisTemplate, RedisTemplate redisTemplate) {
        this.stringRedisTemplate = stringRedisTemplate;
        this.redisTemplate = redisTemplate;
    }

    /***************************************************** Object *****************************************************/

    /**
     * 新增键值对
     *
     * @param key
     * @param obj
     */
    public <T> void putObj(String key, T obj) {
        ValueOperations<String, T> ops = redisTemplate.opsForValue();

        ops.set(key, obj);
    }

    /**
     * 新增键值对（设置了生存时间）
     *
     * @param key
     * @param obj
     * @param seconds
     */
    public <T> void putObj(String key, T obj, int seconds) {
        ValueOperations<String, T> ops = redisTemplate.opsForValue();
        ops.set(key, obj, seconds, TimeUnit.SECONDS);
    }

    /**
     * 获取对象
     * @param key
     * @param <T>
     * @return
     */
    public <T> T getObj(String key) {
        ValueOperations<String, T> ops = redisTemplate.opsForValue();

        return ops.get(key);
    }

    /***************************************************** Hash *****************************************************/

    /**
     * 插入Hset的值
     *
     * @param tableName
     * @param key
     * @param value
     */
    public void putHset(String tableName, String key, String value) {
        BoundHashOperations<String, String, String> ops = stringRedisTemplate.boundHashOps(tableName);

        ops.put(key, value);
    }

    /**
     * 插入Hset的值
     *
     * @param tableName
     * @param paramMap
     */
    public void putHset(String tableName, Map<String, String> paramMap) {
        BoundHashOperations<String, String, String> ops = stringRedisTemplate.boundHashOps(tableName);

        ops.putAll(paramMap);
    }

    /**
     * 设置Hset的生存时间
     *
     * @param tableName
     * @param seconds
     */
    public void setHsetTime(String tableName, int seconds) {
        BoundHashOperations<String, String, String> ops = stringRedisTemplate.boundHashOps(tableName);

        ops.expire(seconds, TimeUnit.SECONDS); // 设置N秒过期
    }

    /**
     * 获取Hset的数据
     *
     * @param tableName
     * @param key
     * @return
     */
    public String getHset(String tableName, String key) {
        BoundHashOperations<String, String, String> ops = stringRedisTemplate.boundHashOps(tableName);

        return ops.get(key);
    }

    /**
     * 获取Hset的数据
     *
     * @param tableName
     * @return
     */
    public Map<String, String> getHset(String tableName) {
        BoundHashOperations<String, String, String> ops = stringRedisTemplate.boundHashOps(tableName);

        return ops.entries();
    }

    /**
     * 根据键名删除Hset里面的键值对
     *
     * @param tableName
     * @param key
     */
    public void delHsetKey(String tableName, String... key) {
        BoundHashOperations<String, String, String> ops = stringRedisTemplate.boundHashOps(tableName);

        ops.delete((Object[]) key);
    }

    /***************************************************** value *****************************************************/

    /**
     * 新增键值对
     *
     * @param key
     * @param value
     */
    public void put(String key, String value) {
        BoundValueOperations<String, String> ops = stringRedisTemplate.boundValueOps(key);

        ops.set(value);
    }

    /**
     * 新增键值对（设置了生存时间）
     *
     * @param key
     * @param value
     * @param seconds
     */
    public void put(String key, String value, int seconds) {
        BoundValueOperations<String, String> ops = stringRedisTemplate.boundValueOps(key);

        ops.set(value, seconds, TimeUnit.SECONDS); // 设置N秒过期
    }

    /**
     * 根据键获取值
     *
     * @param key
     * @return
     */
    public String get(String key) {
        BoundValueOperations<String, String> ops = stringRedisTemplate.boundValueOps(key);

        return ops.get();
    }

    /**
     * 根据键获取值后覆盖新数据
     *
     * @param key
     * @return
     */
    public String getAndSet(String key, String value) {
        BoundValueOperations<String, String> ops = stringRedisTemplate.boundValueOps(key);

        return ops.getAndSet(value);
    }

    /**
     * 删除数据
     *
     * @param key
     */
    public void del(String key) {
        stringRedisTemplate.delete(key);
    }
}
