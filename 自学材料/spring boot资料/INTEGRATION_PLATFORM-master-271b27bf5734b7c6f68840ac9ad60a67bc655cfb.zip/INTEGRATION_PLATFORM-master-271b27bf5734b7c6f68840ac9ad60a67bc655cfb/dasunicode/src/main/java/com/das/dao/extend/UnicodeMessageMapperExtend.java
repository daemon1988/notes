package com.das.dao.extend;

import com.das.domain.UnicodeMessage;

import java.util.List;

    public interface UnicodeMessageMapperExtend {    	
    List<UnicodeMessage>  listAllUnicodeMessage();
    void deleteByMessageName(String messageName);
    List<UnicodeMessage> listByMessageName(String messageName);
    void insertUnicodeMessage(UnicodeMessage unicodeMessage);
}
