package com.das.common.result;

/**
 * 主动推送结果集
 * @author zhangxi
 */
public class BaseResultExtend {
	
    /**
     * 表名
     */
    private String codeSystemName;

    /**
     * 表描述
     */
    private String description;

    /**
     * 属性名称
     */
    private Object properties;

    /**
     * 详细数据
     */
    private Object data;

    public BaseResultExtend() {
    }

    public BaseResultExtend(String codeSystemName, String description, Object properties, Object data) {
        this.codeSystemName = codeSystemName;
        this.description = description;
        this.properties = properties;
        this.data = data;
    }

    public String getCodeSystemName() {
        return codeSystemName;
    }

    public void setCodeSystemName(String codeSystemName) {
        this.codeSystemName = codeSystemName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Object getProperties() {
        return properties;
    }

    public void setProperties(Object properties) {
        this.properties = properties;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "BaseResultExtend{" +
                "codeSystemName='" + codeSystemName + '\'' +
                ", description='" + description + '\'' +
                ", properties=" + properties +
                ", data=" + data +
                '}';
    }
}
