package com.das.service.impl;

import com.das.dao.SysIoShareTableMapper;
import com.das.dao.extend.SysIoShareTableMapperExtend;
import com.das.domain.SysIoShareTable;
import com.das.service.SysIoShareTableService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

/**
 * 共享字典业务层
 * @author zhangxi
 */
@Service("sysIoShareTableService")
public class SysIoShareTableServiceImpl implements SysIoShareTableService {
	
    private static final Logger LOGGER = LoggerFactory.getLogger(SysIoShareTableServiceImpl.class);
    @Autowired
    private SysIoShareTableMapper sysIoShareTableMapper;
    @Autowired
    private SysIoShareTableMapperExtend sysIoShareTableMapperExtend;

    /**
     * 获取共享字典信息
     */
    @Transactional
    @Override
    public List<SysIoShareTable> listShareTable() {
        try {
            //获取有所的共享字典
            List<SysIoShareTable> sysIoShareTableList = sysIoShareTableMapperExtend.listShareTable();
            return sysIoShareTableList;
        } catch (Exception e) {
            LOGGER.info("CatchException:获取共享字典信息错误，" + e);
            throw e;
        }
    }

    /**
     * 根据表名查询共享字典信息
     * @param tableName
     * @return
     */
    @Override
    public SysIoShareTable selectByPrimaryKey(String tableName) {
        return sysIoShareTableMapper.selectByPrimaryKey(tableName);
    }

    /**
     * 查询新数据
     * @param sysIoShareTable
     */
    @Override
    public void insertSysIoShareTable(SysIoShareTable sysIoShareTable) {
        sysIoShareTableMapper.insert(sysIoShareTable);
    }

    /**
     * 删除数据
     * @param tableName
     */
    @Override
    public void delTableByTableName(String tableName) {
        sysIoShareTableMapperExtend.delTableByTableName(tableName);
    }

    /**
     * 更新数据
     * @param sysIoShareTable
     */
    @Override
    public void updateByPrimaryKeySelective(SysIoShareTable sysIoShareTable) {
        sysIoShareTableMapper.updateByPrimaryKeySelective(sysIoShareTable);
    }

    /**
     * 查询数据
     * @param map
     * @return
     */
    @Override
    public List<SysIoShareTable> listTableByCondition(Map map) {
        return sysIoShareTableMapperExtend.listTableByCondition(map);
    }


}
