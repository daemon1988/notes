package com.das.common.util;

import com.das.domain.MyProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * jdbc工具类
 * @author zhangxi
 */
@Component
public class JdbcUtils {
	
    @Resource
    private MyProperties myProperties;

    private  Connection con;
    private  String url ;
    private  String username ;
    private  String password ;
    private  String driverClass ;

    /**
     * 获取连接
     * @return Connection
     */
    public Connection getCon(){
        try {
            url = myProperties.getUrl();
            username = myProperties.getUsername();
            password = myProperties.getPassword();
            driverClass = myProperties.getDriverClassName();
            Class.forName(driverClass);
            con = DriverManager.getConnection(url, username, password);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return con;
    }
}
