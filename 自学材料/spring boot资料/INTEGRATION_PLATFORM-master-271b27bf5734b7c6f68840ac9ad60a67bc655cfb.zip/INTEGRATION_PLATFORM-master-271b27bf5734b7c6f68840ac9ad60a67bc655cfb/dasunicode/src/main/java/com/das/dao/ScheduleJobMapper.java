package com.das.dao;

import com.das.domain.ScheduleJob;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * 定时任务持久层
 * @author : zhangxi
 * @date : 2018-02-24 22:20
 */
public interface ScheduleJobMapper{
	
    /**
     * 查询所有的定时任务
     * @return List<ScheduleJob>
     */
    List<ScheduleJob> listAllJob();

    /**
     * 更新定时任务状态
     * @param scheduleJob
     */
    void updateJobStatusById(ScheduleJob scheduleJob);

    /**
     * 根据主键查询定时任务
     * @param id
     * @return ScheduleJob
     */
    ScheduleJob getScheduleJobByPrimaryKey(int id);

    /**
     * 更新时间表达式
     * @param scheduleJob
     */
    void updateJobCronExpressionById(ScheduleJob scheduleJob);

    /**
     * 新增定时任务
     * @param scheduleJob
     */
    void addScheduleJob(ScheduleJob scheduleJob);
}
