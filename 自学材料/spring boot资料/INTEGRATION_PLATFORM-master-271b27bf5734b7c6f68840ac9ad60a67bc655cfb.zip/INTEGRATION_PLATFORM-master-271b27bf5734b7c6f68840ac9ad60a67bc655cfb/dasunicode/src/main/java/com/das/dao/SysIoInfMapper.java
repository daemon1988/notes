package com.das.dao;

import com.das.domain.SysIoInf;
import org.apache.ibatis.annotations.Mapper;


public interface SysIoInfMapper {
	
    int deleteByPrimaryKey(String ioCode);

    int insert(SysIoInf record);

    int insertSelective(SysIoInf record);

    SysIoInf selectByPrimaryKey(String ioCode);

    int updateByPrimaryKeySelective(SysIoInf record);

    int updateByPrimaryKey(SysIoInf record);
    
}