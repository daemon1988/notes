package com.das.dao.extend;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.das.domain.SysIoInf;
import org.apache.ibatis.annotations.Mapper;

public interface SysIoInfMapperExtend {
	/**
	 * 根据子系统编码更新注册状态
	 * @param status
	 * @param now
	 * @param code
	 * @return
	 */
    int updateStatusByPrimaryKey(Integer status, Date now, String code);
    
    /**
     * 根据账号密码查询子系统
     * @param map
     * @return
     */
    SysIoInf selectByIoCodePassword(Map<String, Object> map);

    /**
     * 根据子系统编码更新密码
     * @param map
     * @return
     */
    int updatePasswordByPrimaryKey(Map<String, Object> map);
	
	/**
     * 查询所有的子系统
     * @return
     */
    List<SysIoInf> listAllSysIoInf();

    /**
     * 更新子系统注册信息
     * @param sysIoInf
     * @return
     */
	int updateSysIoInf(SysIoInf sysIoInf);

	/**
	 * 根据条件查询子系统注册信息
	 * @param sysIoInf
	 * @return
	 */
	List<SysIoInf> listSysIoInfByCondition(SysIoInf sysIoInf);

}
