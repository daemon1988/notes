package com.das.service;

import java.util.List;
import java.util.Map;

import com.das.domain.SysIoTable;

public interface SysIoTableService {
	
	 /**
	  * 注册交换的数据字典
	  * @param queryMap
	  */
	 int insertRegistTable(Map<String, Object> queryMap);

	 /**
	  * 交换字典注册状态查询
	  * @param queryMap
	  * @return
	  */
	SysIoTable getSysIoTableByIoCodeAndTableName(Map<String, Object> queryMap);

	/**
	 * 根据表名获取数据
	 * @param tableName
	 * @return List<SysIoTable>
	 */
	List<SysIoTable> listSysIoTableByTableName(String tableName);

	/**
	 * 根据ioCode查询
	 * @param ioCode
	 * @return List<SysIoTable>
	 */
	List<SysIoTable> listSysIoTableByIoCode(String ioCode);
	
	
}
