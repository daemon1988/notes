package com.das.schedule;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.Charset;
import java.util.Map;

/**
 * @author : zhangxi
 * @date : 2018-02-24 22:34
 */
public class TaskTest1 {
	
    public static final Logger LOGGER = LoggerFactory.getLogger(TaskTest1.class);

    public void run1(){
//        System.out.println("执行方法1");
    }

    public void run2(){
//        System.out.println("执行方法2");
    }

    public static void main(String[] args) {
        String c = null;
        Map<String,Charset> charsets = Charset.availableCharsets();
        for (Map.Entry<String, Charset> entry : charsets.entrySet()) {
//            System.out.println(entry.getKey());
        }
    }
}
