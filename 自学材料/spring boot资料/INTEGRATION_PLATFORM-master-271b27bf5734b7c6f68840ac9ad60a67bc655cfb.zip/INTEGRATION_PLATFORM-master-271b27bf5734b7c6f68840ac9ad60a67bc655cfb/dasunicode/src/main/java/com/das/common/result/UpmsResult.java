package com.das.common.result;

/**
 * @author : zhangxi
 * @date : 2018-02-24 22:06
 */
public class UpmsResult  extends BaseResult {
    public UpmsResult(UpmsEnum upmsEnum, Object data) {
    	
        super(upmsEnum.getCodeMessage(), upmsEnum.getMessage(), data);
    }
}
