package com.das.common.util;



import com.alibaba.fastjson.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.web.client.RestTemplate;

/**
 * 获取token
 */

public class RestUtils {

    /**
     * 获取token
     *
     * @return String
     */
    public static String getToken() {
        String url = "http://192.168.123.233:8082/mq/oauth/token";
        RestTemplate template = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        headers.set("Authorization", "Basic ZGFzOnNlY3JldA==");
        LinkedMultiValueMap body = new LinkedMultiValueMap();
        body.add("grant_type", "password");
        body.add("username", "unicode");
        body.add("password", "unicode");
        HttpEntity entity = new HttpEntity(body, headers);
        String resultJson = template.postForObject(url, entity, String.class);
        return resultJson;
    }

    /**
     * 群发消息
     *
     * @param json
     * @return String
     */
    public static String topicMessage(String token, JSONObject json) {
        String url = "http://192.168.123.233:8082/mq/messages/topic";
        RestTemplate template = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", token);
        HttpEntity<String> entity = new HttpEntity<String>(json.toJSONString(), headers);
        return template.postForObject(url, entity, String.class);
    }

}
