package com.das.controller;

import com.das.common.result.Constant;
import com.das.service.TriggerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("trigger")
public class TriggerController {
    @Autowired
    private TriggerService triggerService;
    /**
     * 添加触发器
     *
     * @param request
     * @return
     */
    @PostMapping("insertTrigger")
    public String insertTrigger(HttpServletRequest request) {
        //获取触发器内容
        String context = request.getParameter("triggerText");
//        System.out.println(context);
        try {
            triggerService.insertTrigger(context);
            return Constant.SUCCESS;
        } catch (Exception e) {
            return Constant.FAILED;
        }
    }
}
