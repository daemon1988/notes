package com.das.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.das.dao.SysIoInfMapper;
import com.das.dao.extend.SysIoInfMapperExtend;
import com.das.domain.SysIoInf;
import com.das.service.SysIoInfService;


@Service("sysIoInfService")
public class SysIoInfServiceImpl implements SysIoInfService{
	
	@Resource
    private SysIoInfMapper sysIoInfMapper;
	@Resource
	private SysIoInfMapperExtend sysIoInfMapperExtend;
	
    @Override
    public void saveMessage(SysIoInf sysIoInf) {
    	sysIoInfMapper.insert(sysIoInf);
    }

    @Override
    public void updateMessage(SysIoInf sysIoInf) {
    	sysIoInfMapper.updateByPrimaryKey(sysIoInf);
    }

    @Override
    public SysIoInf selectByIoCode(String ioCode) {
        return sysIoInfMapper.selectByPrimaryKey(ioCode);
    }

    @Override
    public int updateStatusByCode(SysIoInf sysIoInf) {
        return sysIoInfMapper.updateByPrimaryKeySelective(sysIoInf);
    }

    /**
     * 判断帐密是否正确
     */
    @Override
    public SysIoInf selectByIoCodePassword(Map<String,Object> map){
        return sysIoInfMapperExtend.selectByIoCodePassword(map);
    }

    @Override
    public int updatePasswordByPrimaryKey(Map<String, Object> map) {
        return sysIoInfMapperExtend.updatePasswordByPrimaryKey(map);
    }
    /**
     * 查询所有的注册子系统
     */
    @Override
    public List<SysIoInf> listAllSysIoInf() {
        return sysIoInfMapperExtend.listAllSysIoInf();
    }
    /**
     * 更新子系统注册信息
     */
	@Override
	public int updateByPrimaryKeySelective(SysIoInf sysIoInf) {
		return sysIoInfMapper.updateByPrimaryKeySelective(sysIoInf);
	}

	/**
	 * 根据条件查询子系统注册信息
	 */
	@Override
	public List<SysIoInf> listSysIoInfByCondition(
			SysIoInf sysIoInf) {
		return sysIoInfMapperExtend.listSysIoInfByCondition(sysIoInf);
	}

    /**
	 * 根据帐密封装为sysIoInf类
	 */
	public SysIoInf packingSysIoInfByIoCodeAndPassword(String ioCode,String password){
		SysIoInf sysIoInf = new SysIoInf();
		sysIoInf.setIoCode(ioCode);
		sysIoInf.setPassword(password);
		return sysIoInf;
	}
}
