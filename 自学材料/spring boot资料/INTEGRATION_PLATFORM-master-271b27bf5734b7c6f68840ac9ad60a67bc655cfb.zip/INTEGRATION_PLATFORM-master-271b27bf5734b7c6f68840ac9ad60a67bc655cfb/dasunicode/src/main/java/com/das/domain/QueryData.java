package com.das.domain;

/**
 * 查询条件:针对大量查询条件时提供的类
 * @author : zhangxi
 * @date : 2018-02-24 21:46
 */
public class QueryData {
	
    private int num1;
    private int num2;
    private int num3;
    private int num4;
    private int num5;
    private int num6;
    private int num7;
    private int num8;
    private int num9;
    private int num10;
    private double dou1;
    private double dou2;
    private double dou3;
    private double dou4;
    private double dou5;

    private String str1;
    private String str2;
    private String str3;
    private String str4;
    private String str5;
    private String str6;
    private String str7;
    private String str8;
    private String str9;
    private String str10;

    public QueryData(int num1, int num2, int num3, int num4, int num5, int num6, int num7, int num8, int num9, int num10, double dou1, double dou2, double dou3, double dou4, double dou5, String str1, String str2, String str3, String str4, String str5, String str6, String str7, String str8, String str9, String str10) {
        this.num1 = num1;
        this.num2 = num2;
        this.num3 = num3;
        this.num4 = num4;
        this.num5 = num5;
        this.num6 = num6;
        this.num7 = num7;
        this.num8 = num8;
        this.num9 = num9;
        this.num10 = num10;
        this.dou1 = dou1;
        this.dou2 = dou2;
        this.dou3 = dou3;
        this.dou4 = dou4;
        this.dou5 = dou5;
        this.str1 = str1;
        this.str2 = str2;
        this.str3 = str3;
        this.str4 = str4;
        this.str5 = str5;
        this.str6 = str6;
        this.str7 = str7;
        this.str8 = str8;
        this.str9 = str9;
        this.str10 = str10;
    }

    public QueryData() {
    }

    public int getNum1() {
        return num1;
    }

    public void setNum1(int num1) {
        this.num1 = num1;
    }

    public int getNum2() {
        return num2;
    }

    public void setNum2(int num2) {
        this.num2 = num2;
    }

    public int getNum3() {
        return num3;
    }

    public void setNum3(int num3) {
        this.num3 = num3;
    }

    public int getNum4() {
        return num4;
    }

    public void setNum4(int num4) {
        this.num4 = num4;
    }

    public int getNum5() {
        return num5;
    }

    public void setNum5(int num5) {
        this.num5 = num5;
    }

    public int getNum6() {
        return num6;
    }

    public void setNum6(int num6) {
        this.num6 = num6;
    }

    public int getNum7() {
        return num7;
    }

    public void setNum7(int num7) {
        this.num7 = num7;
    }

    public int getNum8() {
        return num8;
    }

    public void setNum8(int num8) {
        this.num8 = num8;
    }

    public int getNum9() {
        return num9;
    }

    public void setNum9(int num9) {
        this.num9 = num9;
    }

    public int getNum10() {
        return num10;
    }

    public void setNum10(int num10) {
        this.num10 = num10;
    }

    public double getDou1() {
        return dou1;
    }

    public void setDou1(double dou1) {
        this.dou1 = dou1;
    }

    public double getDou2() {
        return dou2;
    }

    public void setDou2(double dou2) {
        this.dou2 = dou2;
    }

    public double getDou3() {
        return dou3;
    }

    public void setDou3(double dou3) {
        this.dou3 = dou3;
    }

    public double getDou4() {
        return dou4;
    }

    public void setDou4(double dou4) {
        this.dou4 = dou4;
    }

    public double getDou5() {
        return dou5;
    }

    public void setDou5(double dou5) {
        this.dou5 = dou5;
    }

    public String getStr1() {
        return str1;
    }

    public void setStr1(String str1) {
        this.str1 = str1;
    }

    public String getStr2() {
        return str2;
    }

    public void setStr2(String str2) {
        this.str2 = str2;
    }

    public String getStr3() {
        return str3;
    }

    public void setStr3(String str3) {
        this.str3 = str3;
    }

    public String getStr4() {
        return str4;
    }

    public void setStr4(String str4) {
        this.str4 = str4;
    }

    public String getStr5() {
        return str5;
    }

    public void setStr5(String str5) {
        this.str5 = str5;
    }

    public String getStr6() {
        return str6;
    }

    public void setStr6(String str6) {
        this.str6 = str6;
    }

    public String getStr7() {
        return str7;
    }

    public void setStr7(String str7) {
        this.str7 = str7;
    }

    public String getStr8() {
        return str8;
    }

    public void setStr8(String str8) {
        this.str8 = str8;
    }

    public String getStr9() {
        return str9;
    }

    public void setStr9(String str9) {
        this.str9 = str9;
    }

    public String getStr10() {
        return str10;
    }

    public void setStr10(String str10) {
        this.str10 = str10;
    }

    @Override
    public String toString() {
        return "QueryData{" +
                "num1=" + num1 +
                ", num2=" + num2 +
                ", num3=" + num3 +
                ", num4=" + num4 +
                ", num5=" + num5 +
                ", num6=" + num6 +
                ", num7=" + num7 +
                ", num8=" + num8 +
                ", num9=" + num9 +
                ", num10=" + num10 +
                ", dou1=" + dou1 +
                ", dou2=" + dou2 +
                ", dou3=" + dou3 +
                ", dou4=" + dou4 +
                ", dou5=" + dou5 +
                ", str1='" + str1 + '\'' +
                ", str2='" + str2 + '\'' +
                ", str3='" + str3 + '\'' +
                ", str4='" + str4 + '\'' +
                ", str5='" + str5 + '\'' +
                ", str6='" + str6 + '\'' +
                ", str7='" + str7 + '\'' +
                ", str8='" + str8 + '\'' +
                ", str9='" + str9 + '\'' +
                ", str10='" + str10 + '\'' +
                '}';
    }
}
