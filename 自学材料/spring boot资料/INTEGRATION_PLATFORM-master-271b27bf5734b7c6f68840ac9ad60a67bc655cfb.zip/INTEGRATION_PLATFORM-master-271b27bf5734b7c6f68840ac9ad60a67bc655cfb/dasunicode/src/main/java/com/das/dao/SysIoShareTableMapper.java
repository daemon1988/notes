package com.das.dao;

import com.das.domain.SysIoShareTable;
import org.apache.ibatis.annotations.Mapper;


public interface SysIoShareTableMapper {
	
    int deleteByPrimaryKey(String tableName);

    int insert(SysIoShareTable record);

    int insertSelective(SysIoShareTable record);

    SysIoShareTable selectByPrimaryKey(String tableName);

    int updateByPrimaryKeySelective(SysIoShareTable record);

    int updateByPrimaryKey(SysIoShareTable record);

}