package com.das.common.result;

import java.util.List;

/**
 * bootstrap table 表格查询结果封装，供前端显示；
 * 包含两个部分：一个是查询到的总记录数，一个是结果集
 * @author : zhangxi
 * @date : 2018-02-24 22:02
 */
public class BootstrapTableResult {
	
    /**
     * 总记录数
     */
    private Integer total;
    /**
     * 结果集的list集合
     */
    private List rows;

    public BootstrapTableResult(Integer total, List rows) {
        this.total = total;
        this.rows = rows;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public List getRows() {
        return rows;
    }

    public void setRows(List rows) {
        this.rows = rows;
    }

    @Override
    public String toString() {
        return "BootstrapTableResult{" +
                "total=" + total +
                ", rows=" + rows +
                '}';
    }
}
