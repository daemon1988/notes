package com.das.dao;

import com.das.domain.UnicodeCompare;
import org.apache.ibatis.annotations.Mapper;


public interface UnicodeCompareMapper {
	
    int insert(UnicodeCompare record);

    int insertSelective(UnicodeCompare record);
}