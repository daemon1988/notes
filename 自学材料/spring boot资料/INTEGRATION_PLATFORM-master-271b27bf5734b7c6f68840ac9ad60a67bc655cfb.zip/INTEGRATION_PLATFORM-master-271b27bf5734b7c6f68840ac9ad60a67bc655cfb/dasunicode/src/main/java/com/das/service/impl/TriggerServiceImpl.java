package com.das.service.impl;

import com.das.common.util.JdbcUtils;
import com.das.service.TriggerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * @author zhangxi
 */

@Service("triggerService")
public class TriggerServiceImpl implements TriggerService{
	
    @Autowired
    private JdbcUtils jdbcUtils;
    /**
     * 插入触发器
     * @param context
     */
    @Override
    public void insertTrigger(String context) throws SQLException {
        String sql = context;
        //获取连接
        Connection con = jdbcUtils.getCon();
        Statement stat = con.createStatement();
        stat.executeUpdate(sql);
        con.close();
        stat.close();
    }
}
