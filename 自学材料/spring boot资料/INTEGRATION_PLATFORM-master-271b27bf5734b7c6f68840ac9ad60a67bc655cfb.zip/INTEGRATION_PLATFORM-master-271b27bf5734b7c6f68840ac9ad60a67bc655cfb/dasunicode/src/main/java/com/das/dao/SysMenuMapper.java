package com.das.dao;

import com.das.domain.QueryData;
import com.das.domain.SysMenu;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * 系统菜单栏持久层
 * @author : zhangxi
 * @date : 2018-02-24 22:22
 */

public interface SysMenuMapper {
	
    /**
     * 获取菜单列表
     * @return List<SysMenu>
     */
    List<SysMenu> listMenu();

    /**
     * 新增菜单/目录/按钮
     * @param sysMenu
     */
    void saveNewMenu(SysMenu sysMenu);

    /**
     * 查询目录,不包括按钮
     * @return
     */
    List<SysMenu> listNoButtonMenu();

    /**
     * 删除单个菜单
     * @param id
     */
    void delMenu(Integer id);

    /**
     * 批量删除菜单
     * @param idList
     */
    void delMenuBatches(List<Integer> idList);

    /**
     * 更新菜单
     * @param sysMenu
     */
    void updateMenu(SysMenu sysMenu);

    /**
     * 根据菜单名称和上级菜单名称查询列表
     * @param queryData
     * @return List<SysMenu>
     */
    List<SysMenu> listMenuByName(QueryData queryData);
}
