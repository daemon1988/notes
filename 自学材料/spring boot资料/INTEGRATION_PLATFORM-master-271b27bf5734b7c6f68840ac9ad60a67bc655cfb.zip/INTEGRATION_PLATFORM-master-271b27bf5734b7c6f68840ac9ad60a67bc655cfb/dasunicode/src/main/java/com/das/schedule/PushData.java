package com.das.schedule;

//import com.alibaba.fastjson.JSON;
//import com.alibaba.fastjson.JSONObject;

import com.alibaba.fastjson.JSONObject;
import com.das.common.configuration.AddressConfiguration;
import com.das.common.rest.Response;
import com.das.common.rest.RestUtil;
import com.das.common.result.BaseResultExtend;
import com.das.common.util.JdbcUtils;
import com.das.common.util.RestUtils;
import com.das.domain.UnicodeCompare;
import com.das.domain.UnicodeMessage;
import com.das.domain.UnicodeTemp;
import com.das.domain.UserTemp;
import com.das.service.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashape.unirest.http.HttpResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.sql.*;
import java.util.*;


/**
 * 定时任务：主动推送数据
 *
 * @author zhangxi
 */
@Service
public class PushData {
    public static final Logger LOGGER = LoggerFactory.getLogger(PushData.class);
    private static PushData pushData;
    @Autowired
    protected SysIoTableService sysIoTableService;
    @Autowired
    protected SysIoInfService sysIoInfService;
    @Autowired
    protected UnicodeCompareService unicodeCompareService;
    @Autowired
    protected JdbcUtils jdbcUtils;
    @Autowired
    protected UnicodeService unicodeService;
    @Autowired
    protected UnicodeMessageService unicodeMessageService;
    @Autowired
    protected UserTempService userTempService;

    @PostConstruct //通过@PostConstruct实现初始化bean之前进行的操作
    public void init() {
        pushData = this;
        pushData.unicodeService = this.unicodeService;
        pushData.unicodeCompareService = this.unicodeCompareService;
        pushData.jdbcUtils = this.jdbcUtils;
        pushData.unicodeCompareService = unicodeCompareService;
        pushData.userTempService = userTempService;
    }

    /**
     * 主动推送编码信息定时任务
     *
     * @throws Exception
     */
    public void pushData1() throws Exception {
        String flag = "NEW";
        try {
            //1. 获取有哪些表发生了变化
            List<UnicodeTemp> unicodeTempList = pushData.unicodeService.listTableNameByFlag(flag);
            //System.out.println("unicodeTempList:"+unicodeTempList.size());
            if (unicodeTempList != null && unicodeTempList.size() != 0) {
                for (UnicodeTemp unicodeTemp : unicodeTempList) {
                    //定义结果集
                    BaseResultExtend baseResultExtend = new BaseResultExtend();
                    // 定义一个list集合存储属性
                    Set propertiesList = new HashSet();

                    //2. 查询该表的几个基本字段；
                    UnicodeCompare unicodeCompare = pushData.unicodeCompareService.getUnicodeCompareByTableName(unicodeTemp.getTableName());
                    String code = unicodeCompare.getCode();
                    String description = unicodeCompare.getDescription();
                    String registerMessageName = unicodeCompare.getRegisterMessageName();

                    //3. 指定接收人
                    List<UnicodeMessage> unicodeMessageList = pushData.unicodeMessageService.listByMessageName(registerMessageName);
                    String messageId = unicodeMessageList.get(0).getMessageId();
//                    System.out.println("messageId is "+messageId);
                    //4. 获取unicodeCompare中的数据，保存ID，用于批量更新状态
                    List<UnicodeTemp> unicodeTempList1 = pushData.unicodeService.getTableData(unicodeTemp.getTableName());

                    //5. 获取具体的数据
                    String sql = "select A.action,A.time as updateTime, B.* from UNICODE_TEMP A," + unicodeCompare.getTableName()
                            + " B WHERE A.code = B." + code;
                    List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
                    //获取表数据
                    Connection con = pushData.jdbcUtils.getCon();
                    Statement stat = con.createStatement();
                    ResultSet rsData = stat.executeQuery(sql);
                    //获取结果集信息，元数据
                    ResultSetMetaData rsmd = rsData.getMetaData();
                    //获取列数
                    int columnCount = rsmd.getColumnCount();
                    //遍历结果集
                    while (rsData.next()) {
                        Map<String, Object> rowData = new HashMap<String, Object>();
                        for (int i = 1; i <= columnCount; i++) {
                            if (!rsmd.getColumnName(i).equalsIgnoreCase(unicodeCompare.getCode())
                                    && !rsmd.getColumnName(i).equalsIgnoreCase(unicodeCompare.getDescription())) {
                                propertiesList.add(rsmd.getColumnName(i));
                                rowData.put(rsmd.getColumnName(i), rsData.getObject(i));
                            } else if (!rsmd.getColumnName(i).equalsIgnoreCase(unicodeCompare.getCode())
                                    && rsmd.getColumnName(i).equalsIgnoreCase(unicodeCompare.getDescription())) {
                                rowData.put("displayName", rsData.getObject(i));
                            } else if (rsmd.getColumnName(i).equalsIgnoreCase(unicodeCompare.getCode())
                                    && !rsmd.getColumnName(i).equalsIgnoreCase(unicodeCompare.getDescription())) {
                                rowData.put("code", rsData.getObject(i));
                            }
                        }
                        list.add(rowData);
                    }

                    baseResultExtend.setCodeSystemName(unicodeCompare.getTableName());
                    baseResultExtend.setDescription(unicodeCompare.getDescription());

                    baseResultExtend.setProperties(propertiesList);
                    baseResultExtend.setData(list);

                    rsData.close();
                    con.close();
                    stat.close();

                    ObjectMapper mapper = new ObjectMapper();
                    String baseResultString = mapper.writeValueAsString(baseResultExtend);
                    JSONObject jsonObj = new JSONObject();
                    //设定消息内容
                    jsonObj.put("messageId", messageId);
                    jsonObj.put("type", "restful");
                    jsonObj.put("content", baseResultString);
                    HttpResponse<Response> response = RestUtil.topicMessage(messageId, "restful", jsonObj.toJSONString());

                    if ("0".equalsIgnoreCase(response.getBody().getResponseCode())) {
                        //推送成功的数据需要更改状态为DONE，下次不在推送
                        for (UnicodeTemp temp : unicodeTempList1) {
                            temp.setFlag("DONE");
                        }
                        //批量更新状态
                        pushData.unicodeService.changeStatus(unicodeTempList1);
                        System.out.println("主动推送数据成功：success");
                    }
                }

            }
        } catch (SQLException e) {
            LOGGER.info("数据库连接失败：" + e);
            throw e;
        } catch (Exception e1) {
            LOGGER.info("获取数据失败：" + e1);
            throw e1;
        }

    }

    /**
     * 主动推送用户到单点登录系统
     */
    public void pushToSso() throws Exception {
        //查询系统中新增的用户
        List<UserTemp> userList = pushData.userTempService.listAllUserTempWithNewStatus();
        System.out.println(userList.size());
        BaseResultExtend baseResultExtend = new BaseResultExtend();
        String sql = "select username,password,nickname,action from UNI_SYS_USER_TEMP WHERE FlAG = 'NEW' and action = 'INSERT'";
        List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
        Set propertiesList = new HashSet();
        //获取表数据
        Connection con = pushData.jdbcUtils.getCon();
        Statement stat = con.createStatement();
        ResultSet rsData = stat.executeQuery(sql);
        //获取结果集信息，元数据
        ResultSetMetaData rsmd = rsData.getMetaData();
        //获取列数
        int columnCount = rsmd.getColumnCount();
        //遍历结果集
        while (rsData.next()) {
            Map<String, Object> rowData = new HashMap<String, Object>();
            for (int i = 1; i <= columnCount; i++) {
                if (!"username".equalsIgnoreCase(rsmd.getColumnName(i))
                        && !"nickname".equalsIgnoreCase(rsmd.getColumnName(i))) {
                    propertiesList.add(rsmd.getColumnName(i));
                    rowData.put(rsmd.getColumnName(i), rsData.getObject(i));
                } else if (!"username".equalsIgnoreCase(rsmd.getColumnName(i))
                        && "nickname".equalsIgnoreCase(rsmd.getColumnName(i))) {
                    rowData.put("displayName", rsData.getObject(i));
                } else if ("username".equalsIgnoreCase(rsmd.getColumnName(i))
                        && !"password".equalsIgnoreCase(rsmd.getColumnName(i))) {
                    rowData.put("code", rsData.getObject(i));
                }
            }
            list.add(rowData);
        }

        baseResultExtend.setCodeSystemName("username");
        baseResultExtend.setDescription("password");

        baseResultExtend.setProperties(propertiesList);
        baseResultExtend.setData(list);

        rsData.close();
        con.close();
        stat.close();
        System.out.println(baseResultExtend);

        ObjectMapper mapper = new ObjectMapper();
        String baseResultString = mapper.writeValueAsString(baseResultExtend);
        JSONObject jsonObj = new JSONObject();
        //获取主动推送给用户的messageId
        List<UnicodeMessage> unicodeMessageList = pushData.unicodeMessageService.listByMessageName(AddressConfiguration.MESSAGE_NAME);
        String messageId = unicodeMessageList.get(0).getMessageId();
        //设定消息内容
        jsonObj.put("messageId", messageId);
        jsonObj.put("type", "restful");
        jsonObj.put("content", baseResultString);
        if (userList != null && userList.size() != 0) {
            HttpResponse<Response> response = RestUtil.topicMessage(messageId, "restful", jsonObj.toJSONString());
            if ("0".equalsIgnoreCase(response.getBody().getResponseCode())) {
//            推送成功的数据需要更改状态为DONE，下次不在推送
                for (UserTemp temp : userList) {
                    temp.setFlag("DONE");
                }
//            批量更新状态
                pushData.userTempService.changeStatus(userList);
            }
        }
    }

    /**
     * 调用token
     * @return String
     */
    public String getToken() {
        String resultJson = RestUtils.getToken();
        JSONObject jsonObject = JSONObject.parseObject(resultJson);
        String token = jsonObject.getString("access_token");
        String tokenType = jsonObject.getString("token_type");
        return tokenType + " " + token;
    }

    /**
     * 群发消息
     */
    public String topicMessage(String token, JSONObject json) {
        return RestUtils.topicMessage(token, json);
    }
}
