package com.das.common.handler;

import com.das.common.rest.RestUtil;
import com.das.common.util.RedisUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * 引入拦截器配置文件
 * @author zhangxi
 */
//@Configuration
public class SessionConfiguration extends WebMvcConfigurerAdapter{
    @Autowired
    private RedisUtils redisUtils;
    
    @Override
    public void addInterceptors(InterceptorRegistry interceptorRegistry){

        interceptorRegistry.addInterceptor(new FrontAuthHandler(redisUtils)).addPathPatterns("/**");
    }
}
