package com.das.service;

import com.das.common.result.BaseResult;
import com.das.common.result.ToHipResult;
import com.das.domain.UnicodeTemp;

import java.util.List;

/**
 * @author zhangxi
 */
public interface UnicodeService {
	
    /**
     * 根据表名获取数据
     * @param tableName
     * @return
     * @throws Exception
     */
    ToHipResult getTableDataByTableName(String tableName) throws Exception;

    /**
     * 获取新增的数据
     * @param flag
     * @return List<UnicodeTemp>
     */
    public List<UnicodeTemp> listTableNameByFlag(String flag);

    /**
     * 更改状态
     */
    public void changeStatus(List list);

    /**
     * 根据表名获取数据
     */
    public List<UnicodeTemp> getTableData(String tableName);

}
