package com.das.domain;

import java.io.Serializable;
import java.util.Date;

public class UnicodeTemp implements Serializable{
	private int id;
    private String tableName;
    private String code;
    private String name;
    private String flag;
    private String action;
    private Date time;

    public UnicodeTemp() {
    }

    public UnicodeTemp(int id, String tableName, String code, String name, String flag, String action, Date time) {
        this.id = id;
        this.tableName = tableName;
        this.code = code;
        this.name = name;
        this.flag = flag;
        this.action = action;
        this.time = time;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public int getId() {
        return id;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "UnicodeTemp{" +
                "id=" + id +
                ", tableName='" + tableName + '\'' +
                ", code='" + code + '\'' +
                ", name='" + name + '\'' +
                ", flag='" + flag + '\'' +
                ", action='" + action + '\'' +
                ", time=" + time +
                '}';
    }
}
