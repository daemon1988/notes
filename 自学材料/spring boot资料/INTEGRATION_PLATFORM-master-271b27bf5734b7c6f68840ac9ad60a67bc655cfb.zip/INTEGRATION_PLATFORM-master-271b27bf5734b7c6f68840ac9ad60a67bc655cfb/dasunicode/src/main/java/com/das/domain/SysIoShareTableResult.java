package com.das.domain;

import java.util.Date;

public class SysIoShareTableResult {
	
	private String code;

    private String displayName;

    private String read;

    private String write;

    private String listen;

	public SysIoShareTableResult() {
		super();
	}

	public SysIoShareTableResult(String code, String displayName, String read, String write, String listen) {
		this.code = code;
		this.displayName = displayName;
		this.read = read;
		this.write = write;
		this.listen = listen;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getRead() {
		return read;
	}

	public void setRead(String read) {
		this.read = read;
	}

	public String getWrite() {
		return write;
	}

	public void setWrite(String write) {
		this.write = write;
	}

	public String getListen() {
		return listen;
	}

	public void setListen(String listen) {
		this.listen = listen;
	}

	@Override
	public String toString() {
		return "SysIoShareTableResult{" +
				"code='" + code + '\'' +
				", displayName='" + displayName + '\'' +
				", read='" + read + '\'' +
				", write='" + write + '\'' +
				", listen='" + listen + '\'' +
				'}';
	}
}
