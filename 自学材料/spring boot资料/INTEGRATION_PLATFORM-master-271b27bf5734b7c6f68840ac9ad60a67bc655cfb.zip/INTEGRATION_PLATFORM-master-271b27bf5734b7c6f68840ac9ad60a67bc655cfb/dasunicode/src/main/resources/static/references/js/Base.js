var contextPath = "/code"
$.extend({
    "infoMsg": function (msg) { //提示信息框
        $.gritter.add({
            title: '提示',
            text: msg,
            class_name: 'gritter-info',
            fade_in_speed: "medium",
            fade_out_speed: 1000,
            time: 3000
        });
    },
    "sucMsg": function (msg) { //成功信息框
        $.gritter.add({
            title: '提示',
            text: msg,
            class_name: 'gritter-success',
            fade_in_speed: "medium",
            fade_out_speed: 1000,
            time: 2000
        });
    },
    "errMsg": function (msg) { //错误信息框
        $.gritter.add({
            title: '提示',
            text: msg,
            class_name: 'gritter-error',
            fade_in_speed: "medium",
            fade_out_speed: 1000,
            time: 5000
        });
    },
    "warnMsg": function (msg) { //警告信息框
        $.gritter.add({
            title: '提示',
            text: msg,
            class_name: 'gritter-warning',
            fade_in_speed: "medium",
            fade_out_speed: 1000,
            time: 3000
        });
    }
});