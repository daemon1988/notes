'use strict';

var access_token;
var startTime;
var expireTime;

function User(userId, password, email, sysName, contact, telephone,auth) {
    this.userId = userId;
    this.password = password;
    this.email = email;
    this.sysName = sysName;
    this.contact = contact;
    this.telephone = telephone;
    this.auth = auth;
}
function Message(msgName, msgDesc, msgFormat, msgSchemaFormat, msgSchemaContent,request,requestUrl) {
    this.msgName = msgName;
    this.msgDesc = msgDesc;
    this.msgFormat = msgFormat;
    this.msgSchemaFormat = msgSchemaFormat;
    this.msgSchemaContent = msgSchemaContent;
    this.request = request;
    this.requestUrl=requestUrl;
}

function ReceiveInfo(receiverId, receiverUrl, auth, username, password) {
    this.receiverId = receiverId;
    this.receiverUrl = receiverUrl;
    this.auth = auth;
    this.username = username;
    this.password = password;
}

function RouteTable(senderId, receivers) {
    this.senderId = senderId;
    this.receivers = receivers;
}

function Route(messageId, routes) {
    this.messageId = messageId;
    this.routes = routes;
}

function clientSignUp(user, success, fail) {
    const settings = {
        "async": true,
        "crossDomain": true,
        "url": "http://192.168.123.233:8082/mq/clients",
        "method": "POST",
        "headers": {
            "Content-Type": "application/json"
        },
        "processData": false,
        "data": JSON.stringify(user)
    };

    $.ajax(settings).done(function (response) {
        if (success !== undefined)
            success(response);
    }).fail(function (jqXHR, status) {
        if (fail !== undefined)
            fail(jqXHR, status);
    });
}

function token(user, success, fail) {
    const settings = {
        "async": false,
        "crossDomain": true,
        "url": "http://192.168.123.233:8082/mq/oauth/token",
        "method": "POST",
        "headers": {
            "Content-Type": "application/x-www-form-urlencoded",
            "Authorization": "Basic ZGFzOnNlY3JldA=="
        },
        "data": {
            "grant_type": "password",
            "username": user.userId,
            "password": user.password
        }
    };

    $.ajax(settings).done(function (response) {
        access_token = response.access_token;
        expireTime = response.expires_in;
        startTime = Date.now();
        if (success !== undefined)
            success(response);
    }).fail(function (jqXHR, status) {
        if (fail !== undefined)
            fail(jqXHR, status);
    });
}

function getToken() {
    if(Date.now() - startTime >= expireTime)
        alert("重新登录");
    return access_token;
}

function registerSchema(message, success, fail) {
    // if (access_token == null)
    //     alert("没有登录");

    const settings = {
        "async": true,
        "crossDomain": true,
        "url": "http://192.168.123.233:8082/mq/schemas",
        "method": "POST",
        "headers": {
            "Content-Type": "application/json",
            "Authorization": "bearer "+getToken(),
        },
        "processData": false,
        "data": JSON.stringify(message)
    };

    $.ajax(settings).done(function (response) {
        if (success !== undefined)
            success(response);
    }).fail(function (jqXHR, status) {
        if (fail !== undefined)
            fail(jqXHR, status);
    });
}

function registerRoutes(route, success, fail) {
    const settings = {
        "async": true,
        "crossDomain": true,
        "url": "http://192.168.123.233:8082/mq/routes",
        "method": "POST",
        "headers": {
            "Authorization": "bearer "+getToken(),
            "Content-Type": "application/json"
        },
        "processData": false,
        "data": JSON.stringify(route)
    };

    $.ajax(settings).done(function (response) {
        if (success !== undefined)
            success(response);
    }).fail(function (jqXHR, status) {
        if (fail !== undefined)
            fail(jqXHR, status);
    });
}